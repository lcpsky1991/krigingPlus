/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ import java.io.BufferedOutputStream;
/*  4:   */ import java.io.FileOutputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.PrintStream;
/*  7:   */ 
/*  8:   */ public class saveResultGMT
/*  9:   */ {
/* 10:   */   int x;
/* 11:   */   int y;
/* 12:   */   int z;
/* 13:   */   private static final double MAX_VAL = 1.0E+064D;
/* 14:   */   private static final double MIN_VAL = -1.0E+064D;
/* 15:   */   private static final double MISSING_VALUE = 1.70141E+038D;
/* 16:   */   
/* 17:   */   public saveResultGMT(String Directory, String filename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] result, double MISSING_VALUE, boolean debug)
/* 18:   */   {
/* 19:49 */     String SaveDirectory = Directory;
/* 20:50 */     String SaveFilename = filename;
/* 21:51 */     Save(Directory, SaveFilename, nx, ny, nz, xv, yv, zv, result, MISSING_VALUE, debug);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void Save(String Directory, String SaveFilename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] result, double MISSING_VALUE, boolean debug)
/* 25:   */   {
/* 26:57 */     double minz = zv[0];
/* 27:58 */     double maxz = zv[(nz - 1)];
/* 28:   */     
/* 29:   */ 
/* 30:61 */     double tmp_scale_x = 1.0D;
/* 31:62 */     double multi_x = 1.0D;
/* 32:63 */     for (double a = -30.0D; a < 30.0D; a += 1.0D)
/* 33:   */     {
/* 34:64 */       tmp_scale_x = Math.pow(10.0D, a);
/* 35:65 */       if (Math.abs(maxz - minz) <= tmp_scale_x)
/* 36:   */       {
/* 37:66 */         multi_x = tmp_scale_x * 10.0D;
/* 38:67 */         break;
/* 39:   */       }
/* 40:   */     }
/* 41:71 */     System.out.println("Export GMT");
/* 42:74 */     for (this.z = 0; this.z < nz; this.z += 1)
/* 43:   */     {
/* 44:   */       long depth;
/* 45:   */       long depth;
/* 46:75 */       if (Math.abs(maxz - minz) > 10.0D) {
/* 47:76 */         depth = zv[this.z];
/* 48:   */       } else {
/* 49:79 */         depth = (zv[this.z] * multi_x);
/* 50:   */       }
/* 51:   */       try
/* 52:   */       {
/* 53:82 */         FileOutputStream out2 = new FileOutputStream(Directory + "_depth=" + depth + "_" + SaveFilename + ".dat");
/* 54:83 */         BufferedOutputStream bout2 = new BufferedOutputStream(out2);
/* 55:84 */         PrintStream pout2 = new PrintStream(bout2);
/* 56:86 */         for (this.y = 0; this.y < ny; this.y += 1) {
/* 57:87 */           for (this.x = 0; this.x < nx; this.x += 1) {
/* 58:88 */             if (result[this.x][this.y][this.z] != MISSING_VALUE) {
/* 59:89 */               pout2.print(xv[this.x] + " " + yv[this.y] + " " + result[this.x][this.y][this.z] + "\n");
/* 60:   */             } else {
/* 61:91 */               pout2.print(xv[this.x] + " " + yv[this.y] + " NaN" + "\n");
/* 62:   */             }
/* 63:   */           }
/* 64:   */         }
/* 65:95 */         pout2.close();
/* 66:96 */         bout2.close();
/* 67:97 */         out2.close();
/* 68:   */       }
/* 69:   */       catch (IOException ioe)
/* 70:   */       {
/* 71:99 */         System.out.println(ioe.toString());
/* 72:   */       }
/* 73:   */     }
/* 74:   */   }
/* 75:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.saveResultGMT
 * JD-Core Version:    0.7.0.1
 */