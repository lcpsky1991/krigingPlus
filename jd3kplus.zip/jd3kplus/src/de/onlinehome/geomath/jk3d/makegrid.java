/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ public class makegrid
/*  4:   */ {
/*  5:   */   public static double[] xv(double dx, int nx, double min_x)
/*  6:   */   {
/*  7:38 */     double[] xv = new double[nx];
/*  8:39 */     xv[0] = min_x;
/*  9:40 */     for (int x = 1; x < nx; x++) {
/* 10:41 */       xv[x] = (xv[(x - 1)] + dx);
/* 11:   */     }
/* 12:43 */     return xv;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public static double[] yv(double dy, int ny, double min_y)
/* 16:   */   {
/* 17:47 */     double[] yv = new double[ny];
/* 18:48 */     yv[0] = min_y;
/* 19:49 */     for (int y = 1; y < ny; y++) {
/* 20:50 */       yv[y] = (yv[(y - 1)] + dy);
/* 21:   */     }
/* 22:52 */     return yv;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static double[] zv(double dz, int nz, double min_z)
/* 26:   */   {
/* 27:56 */     double[] zv = new double[nz];
/* 28:57 */     zv[0] = min_z;
/* 29:58 */     for (int z = 1; z < nz; z++) {
/* 30:59 */       zv[z] = (zv[(z - 1)] + dz);
/* 31:   */     }
/* 32:61 */     return zv;
/* 33:   */   }
/* 34:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.makegrid
 * JD-Core Version:    0.7.0.1
 */