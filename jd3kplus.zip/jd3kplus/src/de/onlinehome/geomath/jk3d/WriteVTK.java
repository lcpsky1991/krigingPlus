/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.BufferedOutputStream;
/*   4:    */ import java.io.FileOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.PrintStream;
/*   7:    */ import java.text.DecimalFormat;
/*   8:    */ 
/*   9:    */ public class WriteVTK
/*  10:    */ {
/*  11:    */   int x;
/*  12:    */   int y;
/*  13:    */   int z;
/*  14:    */   private static final double MAX_VAL = 1.0E+064D;
/*  15:    */   private static final double MIN_VAL = -1.0E+064D;
/*  16:    */   boolean b_trend;
/*  17:    */   double X1;
/*  18:    */   double X2;
/*  19:    */   static final long serialVersionUID = 22L;
/*  20:    */   
/*  21:    */   public WriteVTK(String SaveDirectory, String SaveFilename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] newt, double missingvalue, boolean debug)
/*  22:    */   {
/*  23: 46 */     double dMinNewT = 1.0E+064D;
/*  24: 47 */     double dMaxNewT = -1.0E+064D;double dSumNewT = 0.0D;
/*  25:    */     try
/*  26:    */     {
/*  27: 52 */       FileOutputStream out = new FileOutputStream(SaveDirectory + SaveFilename + ".vtk");
/*  28: 53 */       BufferedOutputStream bout = new BufferedOutputStream(out);
/*  29: 54 */       PrintStream pout = new PrintStream(bout);
/*  30: 56 */       if (debug) {
/*  31: 57 */         System.out.println("SaveVTK: nx,ny,nz: " + nx + " " + ny + " " + nz);
/*  32:    */       }
/*  33: 60 */       String format = "00";
/*  34: 61 */       DecimalFormat intf = new DecimalFormat(format);
/*  35: 62 */       if ((nx < 100) && (ny < 100) && (nz < 100)) {
/*  36: 63 */         format = "00";
/*  37:    */       } else {
/*  38: 65 */         format = "#00";
/*  39:    */       }
/*  40: 69 */       pout.println("# vtk DataFile Version 3.0");
/*  41: 70 */       pout.println(SaveFilename);
/*  42: 71 */       pout.println("ASCII");
/*  43: 72 */       pout.println("DATASET RECTILINEAR_GRID");
/*  44: 73 */       pout.println("DIMENSIONS  " + nx + " " + ny + " " + nz);
/*  45:    */       
/*  46: 75 */       pout.println("X_COORDINATES  " + intf.format(nx) + " float");
/*  47: 76 */       for (this.x = 0; this.x < nx; this.x += 1) {
/*  48: 77 */         pout.print(xv[this.x] + " ");
/*  49:    */       }
/*  50: 79 */       pout.print("\n");
/*  51: 80 */       pout.println("Y_COORDINATES  " + intf.format(ny) + " float");
/*  52: 81 */       for (this.y = 0; this.y < ny; this.y += 1) {
/*  53: 82 */         pout.print(yv[this.y] + " ");
/*  54:    */       }
/*  55: 84 */       pout.print("\n");
/*  56:    */       
/*  57: 86 */       pout.println("Z_COORDINATES  " + intf.format(nz) + " float");
/*  58: 87 */       for (this.z = 0; this.z < nz; this.z += 1) {
/*  59: 88 */         pout.print(zv[this.z] + " ");
/*  60:    */       }
/*  61: 90 */       pout.print("\n");
/*  62:    */       
/*  63: 92 */       pout.println("POINT_DATA " + nx * ny * nz);
/*  64: 93 */       pout.println("SCALARS TEMP float 1");
/*  65: 94 */       pout.println("LOOKUP_TABLE default");
/*  66: 96 */       for (this.z = 0; this.z < nz; this.z += 1) {
/*  67: 97 */         for (this.y = 0; this.y < ny; this.y += 1) {
/*  68: 98 */           for (this.x = 0; this.x < nx; this.x += 1)
/*  69:    */           {
/*  70: 99 */             pout.print(newt[this.x][this.y][this.z] + " ");
/*  71:100 */             if (newt[this.x][this.y][this.z] != missingvalue)
/*  72:    */             {
/*  73:101 */               dMinNewT = Math.min(dMinNewT, newt[this.x][this.y][this.z]);
/*  74:102 */               dMaxNewT = Math.max(dMaxNewT, newt[this.x][this.y][this.z]);
/*  75:103 */               dSumNewT += newt[this.x][this.y][this.z];
/*  76:    */             }
/*  77:    */           }
/*  78:    */         }
/*  79:    */       }
/*  80:108 */       pout.close();
/*  81:109 */       bout.close();
/*  82:110 */       out.close();
/*  83:    */     }
/*  84:    */     catch (IOException ioe)
/*  85:    */     {
/*  86:112 */       System.out.println(ioe.toString());
/*  87:    */     }
/*  88:115 */     double multi_x = 1.0D;
/*  89:116 */     for (double a = -30.0D; a < 30.0D; a += 1.0D)
/*  90:    */     {
/*  91:117 */       double tmp_scale_x = Math.pow(10.0D, a);
/*  92:118 */       if (Math.abs(zv[(nz - 1)] - zv[0]) <= tmp_scale_x)
/*  93:    */       {
/*  94:119 */         multi_x = tmp_scale_x * 10.0D;
/*  95:120 */         break;
/*  96:    */       }
/*  97:    */     }
/*  98:123 */     double depth = 0.0D;
/*  99:124 */     for (this.z = 0; this.z < nz; this.z += 1)
/* 100:    */     {
/* 101:125 */       if (Math.abs(zv[(nz - 1)] - zv[0]) > 10.0D) {
/* 102:126 */         depth = zv[this.z];
/* 103:    */       } else {
/* 104:128 */         depth = (zv[this.z] * multi_x);
/* 105:    */       }
/* 106:130 */       double minf = 1.0E+064D;
/* 107:131 */       double maxf = -1.0E+064D;
/* 108:132 */       for (this.x = 0; this.x < nx; this.x += 1) {
/* 109:133 */         for (this.y = 0; this.y < ny; this.y += 1) {
/* 110:134 */           if (newt[this.x][this.y][this.z] != missingvalue)
/* 111:    */           {
/* 112:135 */             minf = Math.min(minf, newt[this.x][this.y][this.z]);
/* 113:136 */             maxf = Math.max(maxf, newt[this.x][this.y][this.z]);
/* 114:    */           }
/* 115:    */         }
/* 116:    */       }
/* 117:    */     }
/* 118:    */   }
/* 119:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.WriteVTK
 * JD-Core Version:    0.7.0.1
 */