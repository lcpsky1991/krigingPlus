package de.onlinehome.geomath.jk3d.tools;

import de.onlinehome.geomath.jk3d.WriteVTK;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

class TestData3D
{
  public static void main(String[] args)
  {
    int nx = 23;
    int ny = 23;
    int nz = 23;
    double[][][] T = new double[nx][ny][nz];
    double[] xv = new double[nx];
    double[] yv = new double[ny];
    double[] zv = new double[nz];
    try
    {
      FileOutputStream out = new FileOutputStream("original-3D.dat");
      BufferedOutputStream bout = new BufferedOutputStream(out);
      PrintStream pout = new PrintStream(bout);
      for (int z = 0; z < nz; z++) {
        for (int y = 0; y < ny; y++) {
          for (int x = 0; x < nx; x++)
          {
            xv[x] = (x / 20.0D);
            yv[y] = (y / 20.0D);
            zv[z] = (z / 20.0D);
            






















            T[x][y][z] = (0.75D * Math.exp(-0.25D * (Math.pow(9.0D * xv[x] - 2.0D, 2.0D) + Math.pow(9.0D * yv[y] - 2.0D, 2.0D) + Math.pow(9.0D * zv[z] - 2.0D, 2.0D))) + 0.75D * Math.exp(-1.0D * (0.02040816326530612D * Math.pow(9.0D * xv[x] + 1.0D, 2.0D) + 0.1D * (9.0D * yv[y] + 1.0D) + 0.1D * (9.0D * zv[z] + 1.0D))) + 0.5D * Math.exp(-0.25D * (Math.pow(9.0D * xv[x] - 7.0D, 2.0D) + Math.pow(9.0D * yv[y] - 3.0D, 2.0D) + Math.pow(9.0D * zv[z] - 5.0D, 2.0D))) - 0.2D * Math.exp(-1.0D * (Math.pow(9.0D * xv[x] - 4.0D, 2.0D) + Math.pow(9.0D * yv[y] - 7.0D, 2.0D) + Math.pow(9.0D * zv[z] - 5.0D, 2.0D))));
            




            pout.println(xv[x] + "\t" + yv[y] + "\t" + zv[z] + "\t" + T[x][y][z]);
          }
        }
      }
      pout.close();
      bout.close();
      out.close();
    }
    catch (IOException ioe) {}
    new WriteVTK("", "testdata-iw3d-3D-ALL", nx, ny, nz, xv, yv, zv, T, -9999.0D, false);
    try
    {
      FileOutputStream out = new FileOutputStream("testdata-iw3d-3D.dat");
      BufferedOutputStream bout = new BufferedOutputStream(out);
      PrintStream pout = new PrintStream(bout);
      FileOutputStream out2 = new FileOutputStream("testdata-iw3d-3D-missing.dat");
      BufferedOutputStream bout2 = new BufferedOutputStream(out2);
      PrintStream pout2 = new PrintStream(bout2);
      FileOutputStream out3 = new FileOutputStream("testdata-iw3d-3D-ALL.dat");
      BufferedOutputStream bout3 = new BufferedOutputStream(out3);
      PrintStream pout3 = new PrintStream(bout3);
      for (int z = 0; z < nz; z++) {
        for (int y = 0; y < ny; y++) {
          for (int x = 0; x < nx; x++)
          {
            xv[x] = (x / 20.0D);
            yv[y] = (y / 20.0D);
            zv[z] = (z / 20.0D);
            
            double my_rand = Math.random();
            System.out.println(my_rand);
            if (my_rand > 0.9D)
            {
              pout.println(xv[x] + "\t" + yv[y] + "\t" + zv[z] + "\t" + T[x][y][z]);
              pout2.println(xv[x] + "\t" + yv[y] + "\t" + zv[z] + "\t" + T[x][y][z]);
            }
            else
            {
              pout2.println(xv[x] + "\t" + yv[y] + "\t" + zv[z] + "\t" + "-9999.99");
              pout3.println(xv[x] + "\t" + yv[y] + "\t" + zv[z] + "\t" + T[x][y][z]);
            }
          }
        }
      }
      pout.close();
      bout.close();
      out.close();
      pout2.close();
      bout2.close();
      out2.close();
      pout3.close();
      bout3.close();
      out3.close();
    }
    catch (IOException ioe) {}
  }
}



