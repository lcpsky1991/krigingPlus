package de.onlinehome.geomath.jk3d.tools;

import java.io.PrintStream;

public class variogram3d
{
  private static final long serialVersionUID = 22L;
  static final boolean NEAR_OK = false;
  private double min_Temp;
  private double max_Temp;
  private double min_X;
  private double max_X;
  private double min_Y;
  private double max_Y;
  private double min_Z;
  private double max_Z;
  private double[] normTemp;
  private double[] normX;
  private double[] normY;
  private double[] normZ;
  private double[] alpha;
  private double[] beta;
  private double[] X;
  private double[] Y;
  private double[] Z;
  private double[] Temp;
  private static double correlation_length_x;
  private static double correlation_length_y;
  private static double correlation_length_z;
  private static double[][] allData;
  private boolean debug;
  private int ni;
  
  public variogram3d(boolean debug, double[] X0, double[] Y0, double[] Z0, double[] Temp0, double min_X0, double max_X0, double min_Y0, double max_Y0, double min_Z0, double max_Z0, int ni0)
  {
    this.ni = ni0;
    this.min_X = min_X0;
    this.max_X = max_X0;
    this.min_Y = min_Y0;
    this.max_Y = max_Y0;
    this.min_Z = min_Z0;
    this.max_Z = max_Z0;
    
    this.X = new double[this.ni];
    this.Y = new double[this.ni];
    this.Z = new double[this.ni];
    this.Temp = new double[this.ni];
    for (int i = 0; i < this.ni; i++)
    {
      this.X[i] = X0[i];
      this.Y[i] = Y0[i];
      this.Z[i] = Z0[i];
      this.Temp[i] = Temp0[i];
    }
    Progress prg = new Progress();
    prg.start();
  }
  
  class Progress
    extends Thread
  {
    Progress() {}
    
    public void run()
    {
      if (variogram3d.this.debug) {
        System.out.println("semi variogram 1a " + variogram3d.this.X[1] + " " + variogram3d.this.Y[1] + " " + variogram3d.this.Z[1] + " " + variogram3d.this.Temp[1] + " " + variogram3d.this.min_X + " " + variogram3d.this.max_X + " " + variogram3d.this.min_Y + " " + variogram3d.this.max_Y + " " + variogram3d.this.min_Z + " " + variogram3d.this.max_Z + " " + variogram3d.this.ni);
      }
      variogram3d.semiVariogram sv = new variogram3d.semiVariogram(variogram3d.this, variogram3d.this.debug, variogram3d.this.X, variogram3d.this.Y, variogram3d.this.Z, variogram3d.this.Temp, variogram3d.this.min_X, variogram3d.this.max_X, variogram3d.this.min_Y, variogram3d.this.max_Y, variogram3d.this.min_Z, variogram3d.this.max_Z, variogram3d.this.ni, null);
    }
  }
  
  class semiVariogram
  {
    static final long serialVersionUID = 22L;
    
    private semiVariogram(boolean debug, double[] X, double[] Y, double[] Z, double[] Temp, double min_X, double max_X, double min_Y, double max_Y, double min_Z, double max_Z, int ni)
    {
      int ni2 = ni;
      int nj2 = ni;
      int j = nj2;
      int maxl = 20;
      variogram3d.access$1302(new double[maxl][6]);
      
      double nr_of_indizes = 1.0D / maxl / 100.0D;
      if (debug) {
        System.out.println("semi variogram " + min_X + " " + max_X + " " + min_Y + " " + max_Y + " " + min_Z + " " + max_Z + " " + ni);
      }
      double[] gamma_X = new double[ni];
      double[] h_X = new double[ni];
      double[] gamma_Y = new double[ni];
      double[] h_Y = new double[ni];
      double[] gamma_Z = new double[ni];
      double[] h_Z = new double[ni];
      double dist_X = (max_X - min_X) / maxl;
      double dist_Y = (max_Y - min_Y) / maxl;
      double dist_Z = (max_Z - min_Z) / maxl;
      

      double X_TOL = Math.abs((max_X - min_X) / maxl);
      
      double Y_TOL = Math.abs((max_Y - min_Y) / maxl);
      
      double Z_TOL = Math.abs((max_Z - min_Z) / maxl);
      if (debug) {
        System.out.println("X_TOL = " + X_TOL + "Y_TOL = " + Y_TOL + " Z_TOL = " + Z_TOL);
      }
      double theta = 1.570796326794897D;
      
      double XLTOL = dist_X / 2.0D;
      double YLTOL = dist_Y / 2.0D;
      double ZLTOL = dist_Z / 2.0D;
      

      double[] hk_X = new double[maxl];
      double[] hk_Y = new double[maxl];
      double[] hk_Z = new double[maxl];
      
      h_X[0] = 0.0D;
      h_Y[0] = 0.0D;
      h_Z[0] = 0.0D;
      for (int l = 1; l < maxl; l++)
      {
        double gammasum_X = 0.0D;
        double hsum_X = 0.0D;
        double gammasum_Y = 0.0D;
        double hsum_Y = 0.0D;
        double gammasum_Z = 0.0D;
        double hsum_Z = 0.0D;
        int k_X = 0;
        h_X[l] = (dist_X + h_X[(l - 1)]);
        int k_Y = 0;
        h_Y[l] = (dist_Y + h_Y[(l - 1)]);
        int k_Z = 0;
        h_Z[l] = (dist_Z + h_Z[(l - 1)]);
        

        int current = (int)Math.round(l * nr_of_indizes);
        updateProgress(l * (100 / maxl));
        
        j = nj2;
        for (j = nj2 - 1; j >= 0; j--) {
          for (int i = 0; i < ni2; i++) {
            if (j != i)
            {
              double deltax = X[i] - X[j];
              double deltay = Y[i] - Y[j];
              double deltaz = Z[i] - Z[j];
              if ((h_X[(l - 1)] - XLTOL <= deltax) && (deltax <= h_X[l] + XLTOL) && 
                (deltay < Y_TOL) && (deltaz < Z_TOL)) {
                if (deltax < 0.5D * X_TOL)
                {
                  double point_angle_XY = Math.atan(deltax / deltay);
                  
                  double point_angle_XZ = Math.atan(deltax / deltaz);
                  if ((((point_angle_XY < theta) && (point_angle_XZ < theta) ? 1 : 0) | 0x0) != 0)
                  {
                    hsum_X += deltax;
                    gammasum_X += Math.pow(Temp[i] - Temp[j], 2.0D);
                    k_X++;
                  }
                }
                else
                {
                  hsum_X += deltax;
                  gammasum_X += Math.pow(Temp[i] - Temp[j], 2.0D);
                  k_X++;
                }
              }
              if ((h_Y[(l - 1)] - YLTOL <= deltay) && (deltay <= h_Y[l] + YLTOL) && 
                (deltax < X_TOL) && (deltaz < Z_TOL)) {
                if (deltay < 0.5D * Y_TOL)
                {
                  double point_angle_YX = Math.atan(deltay / deltax);
                  
                  double point_angle_YZ = Math.atan(deltay / deltaz);
                  if (((((point_angle_YX < theta) && (point_angle_YZ < theta) ? 1 : 0) | 0x0) != 0) && 
                    (h_Y[(l - 1)] <= deltay) && (deltay < h_Y[l]))
                  {
                    hsum_Y += deltay;
                    gammasum_Y += Math.pow(Temp[i] - Temp[j], 2.0D);
                    k_Y++;
                  }
                }
                else if ((deltay >= 0.5D * Y_TOL) && 
                  (h_Y[(l - 1)] <= deltay) && (deltay < h_Y[l]))
                {
                  hsum_Y += deltay;
                  gammasum_Y += Math.pow(Temp[i] - Temp[j], 2.0D);
                  k_Y++;
                }
              }
              if ((h_Z[(l - 1)] - ZLTOL <= deltaz) && (deltaz <= h_Z[l] + ZLTOL) && 
                (deltax < X_TOL) && (deltay < Y_TOL)) {
                if (deltaz < 0.5D * Z_TOL)
                {
                  double point_angle_ZY = Math.atan(deltaz / deltay);
                  
                  double point_angle_ZX = Math.atan(deltaz / deltax);
                  if (((((point_angle_ZX < theta) && (point_angle_ZY < theta) ? 1 : 0) | 0x0) != 0) && 
                    (h_Z[(l - 1)] <= deltaz) && (deltaz < h_Z[l]))
                  {
                    hsum_Z += deltaz;
                    gammasum_Z += Math.pow(Temp[i] - Temp[j], 2.0D);
                    k_Z++;
                  }
                }
                else if ((deltaz >= 0.5D * Z_TOL) && 
                  (h_Z[(l - 1)] <= deltaz) && (deltaz < h_Z[l]))
                {
                  hsum_Z += deltaz;
                  gammasum_Z += Math.pow(Temp[i] - Temp[j], 2.0D);
                  k_Z++;
                }
              }
            }
          }
        }
        if (k_X >= 30)
        {
          hk_X[l] = (hsum_X / k_X);
          gamma_X[l] = (1.0D / (2.0D * k_X) * gammasum_X);
        }
        else
        {
          hk_X[l] = 0.0D;
          gamma_X[l] = 0.0D;
        }
        if (k_Y >= 30)
        {
          hk_Y[l] = (hsum_Y / k_Y);
          gamma_Y[l] = (1.0D / (2.0D * k_Y) * gammasum_Y);
        }
        else
        {
          hk_Y[l] = 0.0D;
          gamma_Y[l] = 0.0D;
        }
        if (k_Z >= 30)
        {
          hk_Z[l] = (hsum_Z / k_Z);
          gamma_Z[l] = (1.0D / (2.0D * k_Z) * gammasum_Z);
        }
        else
        {
          hk_Z[l] = 0.0D;
          gamma_Z[l] = 0.0D;
        }
        if (debug) {
          System.out.println(l + " " + hk_X[l] + " " + gamma_X[l] + " " + " Pairs(X): " + k_X + " " + hk_Y[l] + " " + gamma_Y[l] + " " + " Pairs(Y): " + k_Y + " " + hk_Z[l] + " " + gamma_Z[l] + " " + " Pairs(Z): " + k_Z);
        }
      }
      for (int l = 1; l < maxl; l++)
      {
        variogram3d.allData[(l - 1)][0] = hk_X[l];
        variogram3d.allData[(l - 1)][1] = gamma_X[l];
        variogram3d.allData[(l - 1)][2] = hk_Y[l];
        variogram3d.allData[(l - 1)][3] = gamma_Y[l];
        variogram3d.allData[(l - 1)][4] = hk_Z[l];
        variogram3d.allData[(l - 1)][5] = gamma_Z[l];
      }
      double max_hk_X = -1.0E+064D;double max_hk_Y = -1.0E-064D;double max_hk_Z = -1.0E-064D;
      for (int l = 1; l < maxl / 2.0D; l++)
      {
        max_hk_X = Math.max(max_hk_X, hk_X[l]);
        max_hk_Y = Math.max(max_hk_Y, hk_Y[l]);
        max_hk_Z = Math.max(max_hk_Z, hk_Z[l]);
      }
      int xc = 0;int yc = 0;int zc = 0;
      for (int l = 1; l < maxl / 2.0D; l++) {
        if (gamma_X[l] >= gamma_X[(l + 1)])
        {
          variogram3d.access$1402(hk_X[l]);
          xc++;
          break;
        }
      }
      for (int l = 1; l < maxl / 2.0D; l++) {
        if (gamma_Y[l] >= gamma_Y[(l + 1)])
        {
          variogram3d.access$1502(hk_Y[l]);
          yc++;
          break;
        }
      }
      for (int l = 1; l < maxl / 2.0D; l++) {
        if (gamma_Z[l] >= gamma_Z[(l + 1)])
        {
          variogram3d.access$1602(hk_Z[l]);
          zc++;
          break;
        }
      }
      if (xc == 0) {
        variogram3d.access$1402(max_hk_X);
      }
      if (yc == 0) {
        variogram3d.access$1502(max_hk_Y);
      }
      if (zc == 0) {
        variogram3d.access$1602(max_hk_Z);
      }
      String clx = variogram3d.correlation_length_x + "";
      String cly = variogram3d.correlation_length_y + "";
      String clz = variogram3d.correlation_length_z + "";
      if (clx.equals("NaN")) {
        variogram3d.access$1402(Math.abs(max_X - min_X));
      }
      if (cly.equals("NaN")) {
        variogram3d.access$1502(Math.abs(max_Y - min_Y));
      }
      if (clz.equals("NaN")) {
        variogram3d.access$1602(Math.abs(max_Z - min_Z));
      }
    }
    
    private void updateProgress(int i) {}
  }
}



