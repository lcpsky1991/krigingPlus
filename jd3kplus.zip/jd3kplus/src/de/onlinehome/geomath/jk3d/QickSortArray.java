/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ public class QickSortArray
/*  4:   */ {
/*  5:   */   public double[][] quicksort(double[][] a)
/*  6:   */   {
/*  7:10 */     quicksort(a, 0, a[1].length - 1);
/*  8:11 */     return a;
/*  9:   */   }
/* 10:   */   
/* 11:   */   private static void quicksort(double[][] a, int l, int r)
/* 12:   */   {
/* 13:14 */     if (l >= r) {
/* 14:14 */       return;
/* 15:   */     }
/* 16:15 */     int m = partition(a, l, r);
/* 17:16 */     quicksort(a, l, m - 1);
/* 18:17 */     quicksort(a, m + 1, r);
/* 19:   */   }
/* 20:   */   
/* 21:   */   private static int partition(double[][] a, int l, int r)
/* 22:   */   {
/* 23:21 */     int i = l + 1;
/* 24:22 */     int j = r;
/* 25:23 */     double p = a[0][l];
/* 26:24 */     while (i <= j) {
/* 27:25 */       if (a[0][i] <= p) {
/* 28:25 */         i++;
/* 29:26 */       } else if (a[0][j] > p) {
/* 30:26 */         j--;
/* 31:   */       } else {
/* 32:27 */         swap(a, i, j);
/* 33:   */       }
/* 34:   */     }
/* 35:29 */     swap(a, l, j);
/* 36:30 */     return j;
/* 37:   */   }
/* 38:   */   
/* 39:   */   private static void swap(double[][] a, int i, int j)
/* 40:   */   {
/* 41:33 */     double[] h = new double[a.length];
/* 42:34 */     for (int s = 0; s < a.length; s++)
/* 43:   */     {
/* 44:35 */       h[s] = a[s][i];
/* 45:36 */       a[s][i] = a[s][j];
/* 46:37 */       a[s][j] = h[s];
/* 47:   */     }
/* 48:   */   }
/* 49:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.QickSortArray
 * JD-Core Version:    0.7.0.1
 */