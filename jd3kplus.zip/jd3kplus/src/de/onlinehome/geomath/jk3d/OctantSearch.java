/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ 
/*   5:    */ public class OctantSearch
/*   6:    */ {
/*   7:    */   static final long serialVersionUID = 1L;
/*   8:    */   private double[] X;
/*   9:    */   private double[] Y;
/*  10:    */   private double[] Z;
/*  11:    */   private double[] Temp;
/*  12:    */   private int q1;
/*  13:    */   private int q2;
/*  14:    */   private int q3;
/*  15:    */   private int q4;
/*  16:    */   private int q5;
/*  17:    */   private int q6;
/*  18:    */   private int q7;
/*  19:    */   private int q8;
/*  20:    */   private double[][] d;
/*  21:    */   private double[][] p;
/*  22:    */   private double[][] T;
/*  23:    */   private double[][] xi;
/*  24:    */   private double[][] yi;
/*  25:    */   private double[][] zi;
/*  26:    */   private int[][] idx0;
/*  27:    */   private double[] dd1;
/*  28:    */   private double[] dd2;
/*  29:    */   private double[] dd3;
/*  30:    */   private double[] dd4;
/*  31:    */   private double[] dd5;
/*  32:    */   private double[] dd6;
/*  33:    */   private double[] dd7;
/*  34:    */   private double[] dd8;
/*  35: 43 */   private boolean[] bd_all = new boolean[8];
/*  36:    */   private double D_TOL;
/*  37:    */   private int empty_OCT;
/*  38: 46 */   private int ni_new = 0;
/*  39:    */   private double[] d_All;
/*  40:    */   private double[] T_All;
/*  41:    */   private double[] phi_All;
/*  42:    */   private double[][] coord;
/*  43:    */   private int[] index;
/*  44:    */   
/*  45:    */   public OctantSearch(boolean debug, double[] X, double[] Y, double[] Z, double[] Temp, int[] idx, double[] phi, double xvv, double yvv, double zvv, int ni, double relation_y, double relation_z, double search_x, double search_y, double search_z, int NR_EMPTY_OCT, int NR_DATA_OCT, double D_TOL)
/*  46:    */   {
/*  47: 63 */     double sum_dist = 0.0D;
/*  48: 64 */     this.d_All = new double[NR_DATA_OCT * 8];
/*  49: 65 */     this.T_All = new double[NR_DATA_OCT * 8];
/*  50: 66 */     this.phi_All = new double[NR_DATA_OCT * 8];
/*  51: 67 */     this.coord = new double[NR_DATA_OCT * 8][3];
/*  52: 68 */     this.index = new int[NR_DATA_OCT * 8];
/*  53:    */     
/*  54: 70 */     boolean b_identic = false;
/*  55:    */     
/*  56:    */ 
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61: 77 */     this.q1 = 0;this.q2 = 0;this.q3 = 0;this.q4 = 0;this.q5 = 0;this.q6 = 0;this.q7 = 0;this.q8 = 0;
/*  62: 78 */     this.d = new double[8][ni];
/*  63: 79 */     this.p = new double[8][ni];
/*  64: 80 */     this.T = new double[8][ni];
/*  65: 81 */     this.xi = new double[8][ni];
/*  66: 82 */     this.yi = new double[8][ni];
/*  67: 83 */     this.zi = new double[8][ni];
/*  68: 84 */     this.idx0 = new int[8][ni];
/*  69: 87 */     for (int i = 0; i < ni; i++)
/*  70:    */     {
/*  71: 88 */       double dx = xvv - X[i];
/*  72: 89 */       double dy = (yvv - Y[i]) * relation_y;
/*  73: 90 */       double dz = (zvv - Z[i]) * relation_z;
/*  74: 91 */       double d_tmp = Math.sqrt(Math.pow(dx, 2.0D) + Math.pow(dy, 2.0D) + Math.pow(dz, 2.0D));
/*  75: 97 */       if (Math.abs(d_tmp) <= D_TOL)
/*  76:    */       {
/*  77: 98 */         b_identic = true;
/*  78: 99 */         if (debug) {
/*  79:100 */           System.out.println("identic " + Math.abs(d_tmp));
/*  80:    */         }
/*  81:102 */         this.d_All[0] = d_tmp;
/*  82:103 */         this.T_All[0] = Temp[i];
/*  83:104 */         this.phi_All[0] = phi[i];
/*  84:105 */         this.coord[0][0] = X[i];
/*  85:106 */         this.coord[0][1] = Y[i];
/*  86:107 */         this.coord[0][2] = Z[i];
/*  87:108 */         this.index[0] = idx[i];
/*  88:109 */         this.empty_OCT = 0;
/*  89:110 */         this.ni_new = 1;
/*  90:    */         
/*  91:    */ 
/*  92:113 */         break;
/*  93:    */       }
/*  94:116 */       double A2 = Math.pow(search_x, 2.0D);
/*  95:117 */       double B2 = Math.pow(search_y * relation_y, 2.0D);
/*  96:118 */       double C2 = Math.pow(search_z * relation_z, 2.0D);
/*  97:119 */       double deltax2 = Math.pow(dx, 2.0D);
/*  98:120 */       double deltay2 = Math.pow(dy, 2.0D);
/*  99:121 */       double deltaz2 = Math.pow(dz, 2.0D);
/* 100:122 */       double ellipsoid = deltax2 / A2 + deltay2 / B2 + deltaz2 / C2;
/* 101:123 */       if (ellipsoid <= 1.0D) {
/* 102:127 */         if ((dx <= 0.0D) && (dy > 0.0D) && (dz <= 0.0D))
/* 103:    */         {
/* 104:128 */           this.d[0][this.q1] = d_tmp;
/* 105:129 */           this.p[0][this.q1] = phi[i];
/* 106:130 */           this.T[0][this.q1] = Temp[i];
/* 107:131 */           this.xi[0][this.q1] = X[i];
/* 108:132 */           this.yi[0][this.q1] = Y[i];
/* 109:133 */           this.zi[0][this.q1] = Z[i];
/* 110:134 */           this.idx0[0][this.q1] = idx[i];
/* 111:135 */           this.q1 += 1;
/* 112:    */         }
/* 113:137 */         else if ((dx > 0.0D) && (dy > 0.0D) && (dz <= 0.0D))
/* 114:    */         {
/* 115:138 */           this.d[1][this.q2] = d_tmp;
/* 116:139 */           this.p[1][this.q2] = phi[i];
/* 117:140 */           this.T[1][this.q2] = Temp[i];
/* 118:141 */           this.xi[1][this.q2] = X[i];
/* 119:142 */           this.yi[1][this.q2] = Y[i];
/* 120:143 */           this.zi[1][this.q2] = Z[i];
/* 121:144 */           this.idx0[1][this.q2] = idx[i];
/* 122:145 */           this.q2 += 1;
/* 123:    */         }
/* 124:147 */         else if ((dx > 0.0D) && (dy <= 0.0D) && (dz <= 0.0D))
/* 125:    */         {
/* 126:148 */           this.d[2][this.q3] = d_tmp;
/* 127:149 */           this.p[2][this.q3] = phi[i];
/* 128:150 */           this.T[2][this.q3] = Temp[i];
/* 129:151 */           this.xi[2][this.q3] = X[i];
/* 130:152 */           this.yi[2][this.q3] = Y[i];
/* 131:153 */           this.zi[2][this.q3] = Z[i];
/* 132:154 */           this.idx0[2][this.q3] = idx[i];
/* 133:155 */           this.q3 += 1;
/* 134:    */         }
/* 135:157 */         else if ((dx <= 0.0D) && (dy <= 0.0D) && (dz <= 0.0D))
/* 136:    */         {
/* 137:158 */           this.d[3][this.q4] = d_tmp;
/* 138:159 */           this.p[3][this.q4] = phi[i];
/* 139:160 */           this.T[3][this.q4] = Temp[i];
/* 140:161 */           this.xi[3][this.q4] = X[i];
/* 141:162 */           this.yi[3][this.q4] = Y[i];
/* 142:163 */           this.zi[3][this.q4] = Z[i];
/* 143:164 */           this.idx0[3][this.q4] = idx[i];
/* 144:165 */           this.q4 += 1;
/* 145:    */         }
/* 146:167 */         else if ((dx <= 0.0D) && (dy > 0.0D) && (dz > 0.0D))
/* 147:    */         {
/* 148:168 */           this.d[4][this.q5] = d_tmp;
/* 149:169 */           this.p[4][this.q5] = phi[i];
/* 150:170 */           this.T[4][this.q5] = Temp[i];
/* 151:171 */           this.xi[4][this.q5] = X[i];
/* 152:172 */           this.yi[4][this.q5] = Y[i];
/* 153:173 */           this.zi[4][this.q5] = Z[i];
/* 154:174 */           this.idx0[4][this.q5] = idx[i];
/* 155:175 */           this.q5 += 1;
/* 156:    */         }
/* 157:177 */         else if ((dx > 0.0D) && (dy > 0.0D) && (dz > 0.0D))
/* 158:    */         {
/* 159:178 */           this.d[5][this.q6] = d_tmp;
/* 160:179 */           this.p[5][this.q6] = phi[i];
/* 161:180 */           this.T[5][this.q6] = Temp[i];
/* 162:181 */           this.xi[5][this.q6] = X[i];
/* 163:182 */           this.yi[5][this.q6] = Y[i];
/* 164:183 */           this.zi[5][this.q6] = Z[i];
/* 165:184 */           this.idx0[5][this.q6] = idx[i];
/* 166:185 */           this.q6 += 1;
/* 167:    */         }
/* 168:187 */         else if ((dx > 0.0D) && (dy <= 0.0D) && (dz > 0.0D))
/* 169:    */         {
/* 170:188 */           this.d[6][this.q7] = d_tmp;
/* 171:189 */           this.p[6][this.q7] = phi[i];
/* 172:190 */           this.T[6][this.q7] = Temp[i];
/* 173:191 */           this.xi[6][this.q7] = X[i];
/* 174:192 */           this.yi[6][this.q7] = Y[i];
/* 175:193 */           this.zi[6][this.q7] = Z[i];
/* 176:194 */           this.idx0[6][this.q7] = idx[i];
/* 177:195 */           this.q7 += 1;
/* 178:    */         }
/* 179:197 */         else if ((dx <= 0.0D) && (dy <= 0.0D) && (dz > 0.0D))
/* 180:    */         {
/* 181:198 */           this.d[7][this.q8] = d_tmp;
/* 182:199 */           this.p[7][this.q8] = phi[i];
/* 183:200 */           this.T[7][this.q8] = Temp[i];
/* 184:201 */           this.xi[7][this.q8] = X[i];
/* 185:202 */           this.yi[7][this.q8] = Y[i];
/* 186:203 */           this.zi[7][this.q8] = Z[i];
/* 187:204 */           this.idx0[7][this.q8] = idx[i];
/* 188:205 */           this.q8 += 1;
/* 189:    */         }
/* 190:    */       }
/* 191:    */     }
/* 192:210 */     if (!b_identic)
/* 193:    */     {
/* 194:211 */       int i2 = 0;
/* 195:212 */       this.empty_OCT = 0;
/* 196:    */       
/* 197:214 */       int[] qq = new int[8];
/* 198:215 */       qq[0] = this.q1;
/* 199:216 */       qq[1] = this.q2;
/* 200:217 */       qq[2] = this.q3;
/* 201:218 */       qq[3] = this.q4;
/* 202:219 */       qq[4] = this.q5;
/* 203:220 */       qq[5] = this.q6;
/* 204:221 */       qq[6] = this.q7;
/* 205:222 */       qq[7] = this.q8;
/* 206:    */       
/* 207:224 */       QickSortArray qsa = new QickSortArray();
/* 208:226 */       for (int a = 0; a < 8; a++) {
/* 209:227 */         if (qq[a] >= NR_DATA_OCT)
/* 210:    */         {
/* 211:228 */           double[][] data = new double[7][qq[a]];
/* 212:229 */           for (int i = 0; i < qq[a]; i++)
/* 213:    */           {
/* 214:230 */             data[0][i] = this.d[a][i];
/* 215:231 */             data[1][i] = this.T[a][i];
/* 216:232 */             data[2][i] = this.p[a][i];
/* 217:233 */             data[3][i] = this.xi[a][i];
/* 218:234 */             data[4][i] = this.yi[a][i];
/* 219:235 */             data[5][i] = this.zi[a][i];
/* 220:236 */             data[6][i] = this.idx0[a][i];
/* 221:    */           }
/* 222:239 */           data = qsa.quicksort(data);
/* 223:241 */           for (int i = 0; i < NR_DATA_OCT; i++)
/* 224:    */           {
/* 225:247 */             this.d_All[i2] = data[0][i];
/* 226:248 */             this.T_All[i2] = data[1][i];
/* 227:249 */             this.phi_All[i2] = data[2][i];
/* 228:250 */             this.coord[i2][0] = data[3][i];
/* 229:251 */             this.coord[i2][1] = data[4][i];
/* 230:252 */             this.coord[i2][2] = data[5][i];
/* 231:253 */             this.index[i2] = ((int)data[6][i]);
/* 232:254 */             i2++;
/* 233:    */           }
/* 234:257 */           this.bd_all[a] = false;
/* 235:    */         }
/* 236:258 */         else if ((qq[a] < NR_DATA_OCT) && (qq[a] > 0))
/* 237:    */         {
/* 238:259 */           this.bd_all[a] = true;
/* 239:260 */           for (int i = 0; i < qq[a]; i++)
/* 240:    */           {
/* 241:261 */             this.d_All[i2] = this.d[a][i];
/* 242:262 */             this.T_All[i2] = this.T[a][i];
/* 243:263 */             this.phi_All[i2] = this.p[a][i];
/* 244:264 */             this.coord[i2][0] = this.xi[a][i];
/* 245:265 */             this.coord[i2][1] = this.yi[a][i];
/* 246:266 */             this.coord[i2][2] = this.zi[a][i];
/* 247:267 */             this.index[i2] = this.idx0[a][i];
/* 248:268 */             i2++;
/* 249:    */           }
/* 250:    */         }
/* 251:    */         else
/* 252:    */         {
/* 253:271 */           this.empty_OCT += 1;
/* 254:    */         }
/* 255:    */       }
/* 256:274 */       this.ni_new = i2;
/* 257:    */     }
/* 258:    */   }
/* 259:    */   
/* 260:    */   public int empty_octants()
/* 261:    */   {
/* 262:280 */     return this.empty_OCT;
/* 263:    */   }
/* 264:    */   
/* 265:    */   public int nr_after_octantsearch()
/* 266:    */   {
/* 267:284 */     return this.ni_new;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public double[] distances()
/* 271:    */   {
/* 272:288 */     return this.d_All;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public double[] errors()
/* 276:    */   {
/* 277:292 */     return this.phi_All;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public double[] values()
/* 281:    */   {
/* 282:296 */     return this.T_All;
/* 283:    */   }
/* 284:    */   
/* 285:    */   public double[][] coords()
/* 286:    */   {
/* 287:300 */     return this.coord;
/* 288:    */   }
/* 289:    */   
/* 290:    */   public int[] index()
/* 291:    */   {
/* 292:304 */     return this.index;
/* 293:    */   }
/* 294:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.OctantSearch
 * JD-Core Version:    0.7.0.1
 */