/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import Jama.Matrix;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ 
/*   6:    */ public class rotateMatrix3D
/*   7:    */ {
/*   8:    */   private Matrix Rx;
/*   9:    */   private Matrix Ry;
/*  10:    */   private Matrix Rz;
/*  11: 37 */   private Matrix v = new Matrix(1, 3);
/*  12:    */   private Matrix rotMatrix;
/*  13:    */   private double[] vrot;
/*  14:    */   
/*  15:    */   public void rotMat3D3(double phix, double phiy, double phiz, double aniy, double aniz)
/*  16:    */   {
/*  17: 50 */     phix = -phix * 3.141592653589793D / 180.0D;
/*  18: 51 */     phiy = -phiy * 3.141592653589793D / 180.0D;
/*  19: 52 */     phiz = -phiz * 3.141592653589793D / 180.0D;
/*  20:    */     
/*  21: 54 */     this.rotMatrix = new Matrix(3, 3);
/*  22:    */     
/*  23:    */ 
/*  24: 57 */     double alpha = phix;
/*  25: 58 */     double beta = phiy;
/*  26: 59 */     double gamma = phiz;
/*  27:    */     
/*  28:    */ 
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33:    */ 
/*  34:    */ 
/*  35:    */ 
/*  36:    */ 
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41: 74 */     this.rotMatrix.set(0, 0, Math.cos(beta) * Math.cos(alpha));
/*  42: 75 */     this.rotMatrix.set(0, 1, Math.cos(beta) * Math.sin(alpha));
/*  43: 76 */     this.rotMatrix.set(0, 2, -Math.sin(beta));
/*  44:    */     
/*  45: 78 */     this.rotMatrix.set(1, 0, -Math.cos(gamma) * Math.sin(alpha) + Math.sin(gamma) * Math.sin(beta) * Math.cos(alpha));
/*  46: 79 */     this.rotMatrix.set(1, 1, Math.cos(gamma) * Math.cos(alpha) + Math.sin(gamma) * Math.sin(beta) * Math.sin(alpha));
/*  47: 80 */     this.rotMatrix.set(1, 2, Math.sin(gamma) * Math.cos(beta));
/*  48:    */     
/*  49: 82 */     this.rotMatrix.set(2, 0, Math.sin(gamma) * Math.sin(alpha) + Math.cos(gamma) * Math.sin(beta) * Math.cos(alpha));
/*  50: 83 */     this.rotMatrix.set(2, 1, -Math.sin(gamma) * Math.cos(alpha) + Math.cos(gamma) * Math.sin(beta) * Math.sin(alpha));
/*  51: 84 */     this.rotMatrix.set(2, 2, Math.cos(gamma) * Math.cos(beta));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static void main(String[] args)
/*  55:    */   {
/*  56:100 */     double phix = 45.0D;
/*  57:101 */     double phiy = 45.0D;
/*  58:102 */     double phiz = 0.0D;
/*  59:    */     
/*  60:104 */     double[] dv = new double[3];
/*  61:105 */     dv[0] = 0.0D;
/*  62:106 */     dv[1] = 0.0D;
/*  63:107 */     dv[2] = 5.0D;
/*  64:108 */     rotateMatrix3D rm3d = new rotateMatrix3D();
/*  65:109 */     rm3d.rotMat3D3(phix, phiy, phiz, 1.0D, 1.0D);
/*  66:110 */     rm3d.myout(dv);
/*  67:    */   }
/*  68:    */   
/*  69:    */   private void myout(double[] dv)
/*  70:    */   {
/*  71:115 */     this.v = new Matrix(1, 3);
/*  72:116 */     this.v.set(0, 0, dv[0]);this.v.set(0, 1, dv[1]);this.v.set(0, 2, dv[2]);
/*  73:117 */     this.v = this.v.times(this.rotMatrix);
/*  74:118 */     System.out.println("Approach 3");
/*  75:119 */     System.out.println(this.v.get(0, 0) + " " + this.v.get(0, 1) + " " + this.v.get(0, 2));
/*  76:    */   }
/*  77:    */   
/*  78:    */   public double[] vrot()
/*  79:    */   {
/*  80:123 */     return this.vrot;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Matrix v()
/*  84:    */   {
/*  85:127 */     return this.v.transpose();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Matrix rotMatrix3D()
/*  89:    */   {
/*  90:131 */     return this.rotMatrix;
/*  91:    */   }
/*  92:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.rotateMatrix3D
 * JD-Core Version:    0.7.0.1
 */