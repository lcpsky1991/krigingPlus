/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ 
/*   5:    */ public class rmDoubles
/*   6:    */ {
/*   7: 34 */   private int ninew = 0;
/*   8:    */   private double[][] datanew;
/*   9:    */   
/*  10:    */   public rmDoubles(int ni0, double[][] data)
/*  11:    */   {
/*  12: 38 */     System.out.print("Removing double values by averaging; before: " + ni0 + " ... ");
/*  13: 39 */     this.datanew = new double[ni0][data[1].length];
/*  14: 40 */     int i3 = 0;
/*  15: 41 */     this.ninew = ni0;
/*  16: 42 */     boolean dv = false;
/*  17: 43 */     for (int i = 0; i < ni0; i++)
/*  18:    */     {
/*  19: 44 */       for (int j = ni0 - 1; j > i; j--) {
/*  20: 45 */         if ((i != j) && (data[i][0] == data[j][0]) && (data[i][1] == data[j][1]) && (data[i][2] == data[j][2]))
/*  21:    */         {
/*  22: 50 */           this.ninew -= 1;
/*  23: 52 */           for (int m = 0; m < data[1].length; m++) {
/*  24: 53 */             this.datanew[i3][m] = data[i][m];
/*  25:    */           }
/*  26: 55 */           data[j][3] = (0.5D * (data[i][3] + data[j][3]));
/*  27: 56 */           if (data[1].length > 4)
/*  28:    */           {
/*  29: 58 */             if (data[i][4] < data[j][4])
/*  30:    */             {
/*  31: 59 */               this.datanew[j][4] = data[i][4];
/*  32: 60 */               data[j][3] = data[i][3];
/*  33:    */             }
/*  34: 61 */             else if (data[i][4] > data[j][4])
/*  35:    */             {
/*  36: 62 */               this.datanew[j][4] = data[j][4];
/*  37: 63 */               data[j][3] = data[j][3];
/*  38:    */             }
/*  39:    */             else
/*  40:    */             {
/*  41: 65 */               this.datanew[j][4] = (0.5D * (data[i][4] + data[j][4]));
/*  42: 66 */               data[j][3] = (0.5D * (data[i][3] + data[j][3]));
/*  43:    */             }
/*  44:    */           }
/*  45:    */           else {
/*  46: 69 */             data[j][3] = (0.5D * (data[i][3] + data[j][3]));
/*  47:    */           }
/*  48: 71 */           dv = true;
/*  49:    */         }
/*  50:    */       }
/*  51: 74 */       if (!dv)
/*  52:    */       {
/*  53: 75 */         for (int m = 0; m < data[1].length; m++) {
/*  54: 76 */           this.datanew[i3][m] = data[i][m];
/*  55:    */         }
/*  56: 78 */         i3++;
/*  57:    */       }
/*  58: 80 */       dv = false;
/*  59:    */     }
/*  60: 82 */     data = new double[this.ninew][data[1].length];
/*  61: 83 */     for (int i = 0; i < this.ninew; i++) {
/*  62: 84 */       for (int m = 0; m < data[1].length; m++) {
/*  63: 85 */         data[i][m] = this.datanew[i][m];
/*  64:    */       }
/*  65:    */     }
/*  66: 88 */     setData(this.datanew);
/*  67: 89 */     System.out.print("after: " + this.ninew);
/*  68: 90 */     System.out.print("... removed " + (ni0 - this.ninew) + " values\n");
/*  69:    */   }
/*  70:    */   
/*  71:    */   private void setData(double[][] data)
/*  72:    */   {
/*  73: 94 */     this.datanew = data;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public double[][] data()
/*  77:    */   {
/*  78: 97 */     return this.datanew;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int ni()
/*  82:    */   {
/*  83:100 */     return this.ninew;
/*  84:    */   }
/*  85:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.rmDoubles
 * JD-Core Version:    0.7.0.1
 */