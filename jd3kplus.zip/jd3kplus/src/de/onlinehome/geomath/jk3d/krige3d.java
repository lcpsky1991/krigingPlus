package de.onlinehome.geomath.jk3d;

import Jama.LUDecomposition;
import Jama.Matrix;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.Vector;

public class krige3d
{
  protected double[] driftScattered;
  protected double[][][] driftGrid;
  protected double[][] driftdata;
  private static double relation_z = 1.0D;
  private static double relation_y = 1.0D;
  protected Matrix v2;
  protected Matrix v;
  protected Matrix tdata;
  protected Matrix x;
  protected Matrix b;
  protected Matrix A;
  protected double[][][] mse;
  protected double[][][] newt;
  protected double[][] data;
  
  public krige3d(int ni0, double[][] data, int nx, int ny, int nz, double min_x, double min_y, double min_z, double dx, double dy, double dz, boolean bErrorVal, boolean debug, int nr_of_variograms, double[] maxRange, double[] minRange, double[] zRange, double[][] variogramAngle, double[] sill, double nugget, String[] variogramType, double search_radius_x, double search_radius_y, double search_radius_z, int NR_DATA_OCT, int NR_EMPTY_OCT, String savedirectory, String savefilename, boolean b_trend, double X1, double X2, int trend_type, String driftfile, double MISSING_VALUE)
  {
    double[] xv = makegrid.xv(dx, nx, min_x);
    double[] yv = makegrid.yv(dy, ny, min_y);
    double[] zv = makegrid.zv(dz, nz, min_z);
    this.newt = new double[nx][ny][nz];
    this.mse = new double[nx][ny][nz];
    
    double[] errorVal0 = new double[ni0];
    if (bErrorVal) {
      for (int i = 0; i < ni0; i++) {
        errorVal0[i] = (1.0D * Math.pow(data[i][4], 2.0D));
      }
    } else {
      for (int i = 0; i < ni0; i++) {
        errorVal0[i] = 0.0D;
      }
    }
    double total = nx * ny * nz;
    double progress = 0.0D;
    int ni = 0;
    
    int empty_octants = 0;
    boolean bOCTANT_SEARCH = false;
    if (NR_DATA_OCT > 0) {
      bOCTANT_SEARCH = true;
    }
    System.out.println("Options: ");
    System.out.println("octant search = " + bOCTANT_SEARCH);
    System.out.println("Save-Filename = " + savefilename);
    System.out.println("Debug = " + debug);
    System.out.println("Error value = " + bErrorVal);
    

    variogramModel vm = new variogramModel();
    rotateMatrix3D rm3d = new rotateMatrix3D();
    transformMatrix3D[] tm3d = new transformMatrix3D[3];
    
    boolean rotate = false;
    for (int m = 0; m < variogramType.length; m++)
    {
      tm3d[m] = new transformMatrix3D(maxRange[m], minRange[m], zRange[m]);
      double aniy = maxRange[m] / minRange[m];
      double aniz = maxRange[m] / zRange[m];
      
      aniy = 1.0D;
      aniz = 1.0D;
      
      rm3d.rotMat3D3(variogramAngle[m][0], variogramAngle[m][1], variogramAngle[m][2], aniy, aniz);
      if ((variogramAngle[m][0] != 0.0D) || (variogramAngle[m][1] != 0.0D) || (variogramAngle[m][2] != 0.0D)) {
        rotate = true;
      }
    }
    if (b_trend)
    {
      double[] ZC = new double[ni0];
      double[] VAL = new double[ni0];
      double[] scr = new double[ni0];
      for (int i = 0; i < ni0; i++)
      {
        ZC[i] = data[i][2];
        VAL[i] = data[i][3];
      }
      scr = trend.removeTrend(VAL, ZC, X1, X2, ni0 - 1);
      for (int i = 0; i < ni0; i++) {
        data[i][3] = scr[i];
      }
    }
    if (trend_type == 1)
    {
      simpleIDW sidw = new simpleIDW();
      sidw.simpleIDW(X2, X2, X2, ni, data);
      loadData lddd = new loadData(true, debug, driftfile);
      this.driftdata = lddd.val();
      int nidd = this.driftdata.length;
      int njdd = this.driftdata[1].length;
      System.out.println("nidd,njdd: " + nidd + " " + njdd);
      

      int alldata = nx * ny * nz;
      alldata = (int)(alldata / 100.0D);
      progress = 0.0D;
      
      System.out.println("Interpolating Drift on Grid ...");
      this.driftGrid = new double[nx][ny][nz];
      for (int zi = 0; zi < nz; zi++) {
        for (int yi = 0; yi < ny; yi++) {
          for (int xi = 0; xi < nx; xi++)
          {
            progress += 1.0D;
            if (progress % alldata == 0.0D)
            {
              double p2 = 100.0D * progress / total;
              String format = "0.0";
              DecimalFormat intf = new DecimalFormat(format);
              if (p2 < 10.0D) {
                format = "0.0";
              } else if (p2 < 100.0D) {
                format = "00.0";
              } else {
                format = "#00.0";
              }
              System.out.println("Progress: " + intf.format(p2) + "%");
            }
            this.driftGrid[xi][yi][zi] = sidw.simpleIDW(xv[xi], yv[yi], zv[zi], nidd, this.driftdata);
          }
        }
      }
      writedata3d wd3d = new writedata3d(savedirectory + "driftGrid.dat", xv, yv, zv, this.driftGrid);
      

      System.out.println("Interpolating Drift on Scattered Data Locations ...");
      alldata = ni0;
      alldata = (int)(alldata / 100.0D);
      progress = 0.0D;
      this.driftScattered = new double[ni0];
      for (int i = 0; i < ni0; i++)
      {
        double xc = data[i][0];
        double yc = data[i][1];
        double zc = data[i][2];
        progress += 1.0D;
        if (progress % alldata == 0.0D)
        {
          double p2 = 100.0D * progress / total;
          String format = "0.0";
          DecimalFormat intf = new DecimalFormat(format);
          if (p2 < 10.0D) {
            format = "0.0";
          } else if (p2 < 100.0D) {
            format = "00.0";
          } else {
            format = "#00.0";
          }
          System.out.println("Progress: " + intf.format(p2) + "%");
        }
        this.driftScattered[i] = sidw.simpleIDW(xc, yc, zc, nidd, this.driftdata);
      }
    }
    int alldata = nx * ny * nz;
    alldata = (int)(alldata / 100.0D);
    

    this.v = new Matrix(3, 1);
    this.v2 = new Matrix(3, 1);
    for (int zi = 0; zi < nz; zi++) {
      for (int yi = 0; yi < ny; yi++) {
        for (int xi = 0; xi < nx; xi++)
        {
          double[][] datanew;
          if (bOCTANT_SEARCH)
          {
            double D_TOL = 1.0E-008D;
            double[] XC = new double[ni0];
            double[] YC = new double[ni0];
            double[] ZC = new double[ni0];
            double[] VAL = new double[ni0];
            int[] IDX = new int[ni0];
            for (int i = 0; i < ni0; i++)
            {
              XC[i] = data[i][0];
              YC[i] = data[i][1];
              ZC[i] = data[i][2];
              VAL[i] = data[i][3];
              IDX[i] = i;
            }
            OctantSearch os = new OctantSearch(debug, XC, YC, ZC, VAL, IDX, errorVal0, xv[xi], yv[yi], zv[zi], ni0, relation_y, relation_z, search_radius_x, search_radius_y, search_radius_z, NR_EMPTY_OCT, NR_DATA_OCT, D_TOL);
            



            ni = os.nr_after_octantsearch();
            empty_octants = os.empty_octants();
            
            double[][] datanew = new double[ni][6];
            for (int i = 0; i < ni; i++)
            {
              datanew[i][0] = os.coords()[i][0];
              datanew[i][1] = os.coords()[i][1];
              datanew[i][2] = os.coords()[i][2];
              datanew[i][3] = os.values()[i];
              datanew[i][4] = os.errors()[i];
              datanew[i][5] = os.index()[i];
            }
          }
          else
          {
            Vector<Double> vec = new Vector();
            int nrE = 0;
            for (int i = 0; i < ni0; i++)
            {
              double dataDistance = euclidianDistance(data[i][0], xv[xi], data[i][1], yv[yi], data[i][2], zv[zi]);
              
              double dx0 = data[i][0] - xv[xi];
              double dy0 = (data[i][1] - yv[yi]) * relation_y;
              double dz0 = (data[i][2] - zv[zi]) * relation_z;
              
              double A2 = Math.pow(search_radius_x, 2.0D);
              double B2 = Math.pow(search_radius_y * relation_y, 2.0D);
              double C2 = Math.pow(search_radius_z * relation_z, 2.0D);
              double deltax2 = Math.pow(dx0, 2.0D);
              double deltay2 = Math.pow(dy0, 2.0D);
              double deltaz2 = Math.pow(dz0, 2.0D);
              double ellipsoid = deltax2 / A2 + deltay2 / B2 + deltaz2 / C2;
              if (ellipsoid <= 1.0D)
              {
                vec.addElement(Double.valueOf(data[i][0]));
                vec.addElement(Double.valueOf(data[i][1]));
                vec.addElement(Double.valueOf(data[i][2]));
                vec.addElement(Double.valueOf(data[i][3]));
                vec.addElement(Double.valueOf(errorVal0[i]));
                vec.addElement(Double.valueOf(i));
                nrE++;
              }
            }
            ni = nrE;
            if (debug) {
              System.out.println("nrE = " + nrE);
            }
            datanew = new double[ni][6];
            int ii = 0;
            for (int i = 0; i < ni; i++) {
              for (int j = 0; j < 6; j++)
              {
                Object f = vec.elementAt(ii);
                ii++;
                datanew[i][j] = Double.valueOf(f.toString()).doubleValue();
              }
            }
          }
          this.A = new Matrix(ni + 1, ni + 1);
          this.b = new Matrix(ni + 1, 1);
          if (trend_type == 1)
          {
            this.A = new Matrix(ni + 2, ni + 2);
            this.b = new Matrix(ni + 2, 1);
          }
          this.tdata = new Matrix(ni, 1);
          this.A.set(ni, 0, 1.0D);
          this.A.set(0, ni, 1.0D);
          for (int i = 1; i < ni; i++)
          {
            this.A.set(ni, i, 1.0D);
            this.A.set(i, ni, 1.0D);
            for (int j = 0; j < ni - 1; j++)
            {
              double valscr = 0.0D;
              for (int m = 0; m < variogramType.length; m++)
              {
                this.v.set(0, 0, datanew[i][0]);
                this.v.set(1, 0, datanew[i][1]);
                this.v.set(2, 0, datanew[i][2]);
                this.v = tm3d[m].transfMatrix3D().times(rm3d.rotMatrix3D().times(this.v));
                

                this.v2.set(0, 0, datanew[j][0]);
                this.v2.set(1, 0, datanew[j][1]);
                this.v2.set(2, 0, datanew[j][2]);
                this.v2 = tm3d[m].transfMatrix3D().times(rm3d.rotMatrix3D().times(this.v2));
                




                double[] rotData1 = this.v.getColumnPackedCopy();
                double[] rotData2 = this.v2.getColumnPackedCopy();
                

                double realMaxRange = Math.max(maxRange[m], Math.max(minRange[m], zRange[m]));
                valscr += vm.variogramModel(variogramType[m], nugget, sill[m], 1.0D, euclidianDistance(rotData1[0], rotData2[0], rotData1[1], rotData2[1], rotData1[2], rotData2[2]));
              }
              this.A.set(i, j, valscr);
              this.A.set(j, i, valscr);
              if (i == j) {
                this.A.set(j, i, datanew[j][4]);
              }
            }
          }
          if (trend_type == 1) {
            for (int i = 0; i < ni; i++)
            {
              this.A.set(ni + 1, i, this.driftScattered[((int)datanew[i][5])]);
              this.A.set(i, ni + 1, this.driftScattered[((int)datanew[i][5])]);
            }
          }
          for (int i = 0; i < ni; i++)
          {
            this.tdata.set(i, 0, datanew[i][3]);
            

            double valscr = 0.0D;
            for (int m = 0; m < variogramType.length; m++)
            {
              this.v.set(0, 0, datanew[i][0]);
              this.v.set(1, 0, datanew[i][1]);
              this.v.set(2, 0, datanew[i][2]);
              this.v = tm3d[m].transfMatrix3D().times(rm3d.rotMatrix3D().times(this.v));
              
              this.v2.set(0, 0, xv[xi]);
              this.v2.set(1, 0, yv[yi]);
              this.v2.set(2, 0, zv[zi]);
              this.v2 = tm3d[m].transfMatrix3D().times(rm3d.rotMatrix3D().times(this.v2));
              
              double[] rotData1 = this.v.getColumnPackedCopy();
              double[] rotData2 = this.v2.getColumnPackedCopy();
              
              double realMaxRange = Math.max(maxRange[m], Math.max(minRange[m], zRange[m]));
              
              valscr += vm.variogramModel(variogramType[m], nugget, sill[m], 1.0D, euclidianDistance(rotData1[0], rotData2[0], rotData1[1], rotData2[1], rotData1[2], rotData2[2]));
            }
            this.b.set(i, 0, valscr);
          }
          this.b.set(ni, 0, 1.0D);
          if (trend_type == 1) {
            this.b.set(ni + 1, 0, this.driftGrid[xi][yi][zi]);
          }
          boolean pseudoInverse = false;
          boolean bSingular = false;
          if (this.A.lu().isNonsingular())
          {
            this.x = this.A.solve(this.b);
          }
          else
          {
            Matrices m = new Matrices();
            this.A = Matrices.pinv(this.A);
            this.x = this.A.times(this.b);
            bSingular = true;
          }
          if (trend_type == 1) {
            this.newt[xi][yi][zi] = dotproduct(this.x.getMatrix(0, this.x.getRowDimension() - 3, 0, this.x.getColumnDimension() - 1).transpose(), this.tdata);
          } else {
            this.newt[xi][yi][zi] = dotproduct(this.x.getMatrix(0, this.x.getRowDimension() - 2, 0, this.x.getColumnDimension() - 1).transpose(), this.tdata);
          }
          this.mse[xi][yi][zi] = (-1.0D * dotproduct(this.b.transpose(), this.x));
          if ((bOCTANT_SEARCH) && (empty_octants > NR_EMPTY_OCT))
          {
            this.newt[xi][yi][zi] = MISSING_VALUE;
            this.mse[xi][yi][zi] = MISSING_VALUE;
          }
          progress += 1.0D;
          if (progress % alldata == 0.0D)
          {
            double p2 = 100.0D * progress / total;
            String format = "0.0";
            DecimalFormat intf = new DecimalFormat(format);
            if (p2 < 10.0D) {
              format = "0.0";
            } else if (p2 < 100.0D) {
              format = "00.0";
            } else {
              format = "#00.0";
            }
            System.out.println("Progress: " + intf.format(p2) + "%");
          }
        }
      }
    }
    if (b_trend) {
      trend.addTrend(this.newt, zv, X1, X2, nx - 1, ny - 1, nz - 1, MISSING_VALUE);
    }
    double minval = 1.7976931348623157E+308D;
    double maxval = -1.797693134862316E+308D;
    for (int zi = 0; zi < nz; zi++) {
      for (int yi = 0; yi < ny; yi++) {
        for (int xi = 0; xi < nx; xi++) {
          if (this.newt[xi][yi][zi] != MISSING_VALUE)
          {
            minval = Math.min(this.newt[xi][yi][zi], minval);
            maxval = Math.max(this.newt[xi][yi][zi], maxval);
          }
        }
      }
    }
    System.out.println("minimum value = " + minval);
    System.out.println("maximum value = " + maxval);
    


    new saveResultsurferGrd(savefilename, nx, ny, nz, xv, yv, zv, this.newt);
    new WriteVTK(savedirectory, savefilename, nx, ny, nz, xv, yv, zv, this.newt, MISSING_VALUE, debug);
    new saveResultGMT(savedirectory, savefilename, nx, ny, nz, xv, yv, zv, this.newt, MISSING_VALUE, debug);
    new saveResultTecplot(savedirectory, savefilename + ".plt", nx, ny, nz, xv, yv, zv, this.newt);
    new WriteVTK(savedirectory, "mse_" + savefilename, nx, ny, nz, xv, yv, zv, this.mse, MISSING_VALUE, debug);
    new saveResultGMT(savedirectory, "mse_" + savefilename, nx, ny, nz, xv, yv, zv, this.mse, MISSING_VALUE, debug);
  }
  
  public double euclidianDistance(double x1, double x2, double y1, double y2, double z1, double z2)
  {
    double ec = Math.sqrt(Math.pow(x2 - x1, 2.0D) + Math.pow(y2 - y1, 2.0D) + Math.pow(z2 - z1, 2.0D));
    return ec;
  }
  
  public double dotproduct(Matrix A, Matrix B)
  {
    double[][] a = A.getArray();
    double[][] b = B.getArray();
    double dp = 0.0D;
    for (int i = 0; i < a[0].length; i++) {
      dp += a[0][i] * b[i][0];
    }
    return dp;
  }
}



