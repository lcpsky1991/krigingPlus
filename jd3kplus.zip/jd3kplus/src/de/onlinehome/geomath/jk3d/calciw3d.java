package de.onlinehome.geomath.jk3d;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DecimalFormat;

public class calciw3d
{
  static final long serialVersionUID = 22L;
  long current;
  
  public calciw3d(int ni0, double[][] data, int nx, int ny, int nz, double min_x, double min_y, double min_z, double dx, double dy, double dz, double beta, double delta, boolean b_trend, double X1, double X2, String topofile, int assign_missing_value_when_lessdata_than, double missingvalue, boolean bErrorVal, boolean debug, double search_x_new, double search_y_new, double search_z_new, int NR_DATA_OCT, int NR_EMPTY_OCT, int i_normalize, boolean normalize_only_z, String savefilename, int externalGrid, String externalGridFile)
  {
    if (((beta < 0.0D ? 1 : 0) | (delta < 0.0D ? 1 : 0)) != 0)
    {
      System.out.println("power and smoothing paramters are wrong/unset: " + beta + " " + delta + "\n" + "stoping!");
      System.exit(0);
    }
    System.out.println("power and smoothing paramters are: " + beta + " " + delta + " error-weighting = " + bErrorVal);
    double[] xv = makegrid.xv(dx, nx, min_x);
    double[] yv = makegrid.yv(dy, ny, min_y);
    double[] zv0 = makegrid.zv(dz, nz, min_z);
    double[][][] zv = new double[nx][ny][nz];
    for (int zi = 0; zi < nz; zi++) {
      for (int yi = 0; yi < ny; yi++) {
        for (int xi = 0; xi < nx; xi++) {
          zv[xi][yi][zi] = zv0[zi];
        }
      }
    }
    if (externalGrid == 3)
    {
      int nig = 0;
      loadData ld = new loadData(false, debug, externalGridFile);
      double[][] griddata = ld.val();
      nig = griddata.length;
      int njg = griddata[1].length;
      System.out.println("external grid - ni,nj: " + nig + " " + njg);
      int i = 0;
      for (int zi = 0; zi < nz; zi++) {
        for (int yi = 0; yi < ny; yi++) {
          for (int xi = 0; xi < nx; xi++)
          {
            xv[xi] = griddata[i][0];
            yv[yi] = griddata[i][1];
            zv[xi][yi][zi] = griddata[i][2];
            i++;
          }
        }
      }
    }
    double deltax = 0.0D;double deltay = 0.0D;double deltaz = 0.0D;
    double omega = 0.0D;double tau = 0.0D;double vecdist = 0.0D;
    long scr11 = 0L;long scr12 = 0L;
    



    double max_x = min_x + nx * dx;
    double max_y = min_y + ny * dy;
    double max_z = min_z + nz * dz;
    
    double D_TOL = Math.sqrt(Math.pow(max_x - min_x, 2.0D) + Math.pow(max_y - min_y, 2.0D) + Math.pow(max_z - min_z, 2.0D));
    


    D_TOL *= 1.0E-012D;
    if (debug) {
      System.out.println("calciw3d 2 ni0 = " + ni0 + " D_TOL = " + D_TOL);
    }
    double[] XC = new double[ni0];
    double[] YC = new double[ni0];
    double[] ZC = new double[ni0];
    double[] VAL = new double[ni0];
    double[] errorVal = new double[ni0];
    int[] IDX = new int[ni0];
    
    double ignore_values_with_an_error_larger_than = 10.0D;
    for (int i = 0; i < ni0; i++)
    {
      XC[i] = data[i][0];
      YC[i] = data[i][1];
      ZC[i] = data[i][2];
      VAL[i] = data[i][3];
      IDX[i] = i;
      if (bErrorVal)
      {
        errorVal[i] = (1.0D - data[i][4] / ignore_values_with_an_error_larger_than);
        errorVal[i] = data[i][4];
        if (errorVal[i] < 0.0D) {
          errorVal[i] = 0.0D;
        }
      }
      else
      {
        errorVal[i] = 1.0D;
      }
      System.out.println("errorVal " + i + " " + errorVal[i]);
    }
    double width_XC = max_x - min_x;
    double width_YC = max_y - min_y;
    double width_ZC = max_z - min_z;
    double relation_z;
    double relation_y;
    double relation_z;
    if (i_normalize == 1)
    {
      double relation_y;
      double relation_y;
      if (!normalize_only_z) {
        relation_y = dx / dy;
      } else {
        relation_y = 1.0D;
      }
      relation_z = dx / dz;
    }
    else
    {
      double relation_z;
      if (i_normalize == 2)
      {
        double relation_y;
        double relation_y;
        if (!normalize_only_z) {
          relation_y = width_XC / width_YC;
        } else {
          relation_y = 1.0D;
        }
        relation_z = width_XC / width_ZC;
      }
      else
      {
        double relation_z;
        if (i_normalize == 3)
        {
          double relation_y;
          double relation_y;
          if (!normalize_only_z) {
            relation_y = dx / dy * (width_XC / width_YC);
          } else {
            relation_y = 1.0D;
          }
          relation_z = dx / dz * (width_XC / width_ZC);
        }
        else
        {
          relation_y = 1.0D;
          relation_z = 1.0D;
        }
      }
    }
    if (debug) {
      System.out.println("search_x: " + search_x_new + " search_y: " + search_y_new + " search_z: " + search_z_new);
    }
    double[][][] newt = new double[nx][ny][nz];
    
    double wx = 1.0D;
    double wy = 1.0D;
    double wz = 1.0D;
    if (search_x_new > 0.0D) {
      wx = search_x_new;
    } else {
      wx = 2.0D * (max_x - min_x);
    }
    if (search_y_new > 0.0D) {
      wy = search_y_new;
    } else {
      wy = 2.0D * (max_y - min_y);
    }
    if (search_z_new > 0.0D) {
      wz = search_z_new;
    } else {
      wz = 2.0D * (max_z - min_z);
    }
    boolean bOCTANT_SEARCH = false;
    if (NR_DATA_OCT > 0) {
      bOCTANT_SEARCH = true;
    }
    if (debug) {
      System.out.println("start: Calciw3d - new wx,wy,wz:" + wx + " " + wy + " " + wz + "\n" + "relation_y + relation_z: " + relation_y + " " + relation_z + "\n" + "dx,dy,dz:" + dx + " " + dy + " " + dz + "\n" + "beta, delta: " + beta + " " + delta + "\n" + "bOCTANT_SEARCH: " + bOCTANT_SEARCH + " NR_EMPTY_OCT: " + NR_EMPTY_OCT + "\n" + "NR_DATA_OCT: " + NR_DATA_OCT + "\n" + "normalize_only_z: " + normalize_only_z + "\n" + "b_trend: " + b_trend + " X1 = " + X1 + " X2 = " + X2 + "\nmissingvalue = " + missingvalue);
    }
    long sum = 0L;
    double nr_of_indizes = 1.0D / (ni0 * nx * ny * nz / 100.0D);
    long scr_progress = (ni0 * nx * ny * nz / 1000.0D);
    long begin = System.currentTimeMillis();
    if (debug)
    {
      double min_phi = 1.7976931348623157E+308D;
      double max_phi = 4.9E-324D;
      for (int i = 0; i < ni0; i++)
      {
        min_phi = Math.min(errorVal[i], min_phi);
        max_phi = Math.max(errorVal[i], max_phi);
      }
      System.out.println("min_phi + max_phi " + min_phi + " " + max_phi);
    }
    if (b_trend) {
      trend.removeTrendGrid(VAL, XC, YC, ZC, X1, X2, topofile, ni0);
    }
    writeNearData(nx, ny, nz, XC, YC, ZC, ni0, xv, yv, zv, 1000.0D, 1000.0D, 100.0D);
    











    int empty_octants = 0;
    int ni = 0;
    double[][] datanew = new double[1][5];
    if (bOCTANT_SEARCH)
    {
      if (debug) {
        System.out.println("begin of loops - octant search!");
      }
      int progress = 0;double total = nx * ny * nz;
      for (int zi = 0; zi < nz; zi++) {
        for (int yi = 0; yi < ny; yi++) {
          for (int xi = 0; xi < nx; xi++)
          {
            OctantSearch os = new OctantSearch(debug, XC, YC, ZC, VAL, IDX, errorVal, xv[xi], yv[yi], zv[xi][yi][zi], ni0, relation_y, relation_z, wx, wy, wz, NR_EMPTY_OCT, NR_DATA_OCT, D_TOL);
            



            ni = os.nr_after_octantsearch();
            empty_octants = os.empty_octants();
            
            datanew = new double[ni][5];
            for (int i = 0; i < ni; i++)
            {
              datanew[i][0] = os.coords()[i][0];
              datanew[i][1] = os.coords()[i][1];
              datanew[i][2] = os.coords()[i][2];
              datanew[i][3] = os.values()[i];
              datanew[i][4] = os.errors()[i];
            }
            if (ni < assign_missing_value_when_lessdata_than)
            {
              newt[xi][yi][zi] = missingvalue;
            }
            else
            {
              omega = 0.0D;tau = 0.0D;
              boolean b_identic = false;
              for (int i = 0; i < ni; i++)
              {
                sum += 1L;
                if (sum % scr_progress == 0L) {
                  this.current = Math.round(sum * nr_of_indizes);
                }
                deltax = Math.pow(datanew[i][0] - xv[xi], 2.0D);
                deltay = Math.pow((datanew[i][1] - yv[yi]) * relation_y, 2.0D);
                deltaz = Math.pow((datanew[i][2] - zv[xi][yi][zi]) * relation_z, 2.0D);
                double scattered_data_vecdist = Math.sqrt(deltax + deltay + deltaz);
                if (Math.abs(scattered_data_vecdist) < D_TOL)
                {
                  b_identic = true;
                  if (debug) {
                    System.out.println("identic " + Math.abs(scattered_data_vecdist));
                  }
                  newt[xi][yi][zi] = datanew[i][3];
                  break;
                }
                vecdist = Math.sqrt(Math.pow(scattered_data_vecdist, 2.0D) + Math.pow(delta, 2.0D));
                omega += datanew[i][4] * datanew[i][3] / Math.pow(vecdist, beta);
                tau += datanew[i][4] * 1.0D / Math.pow(vecdist, beta);
              }
              if (!b_identic)
              {
                newt[xi][yi][zi] = (omega / tau);
                if (empty_octants > NR_EMPTY_OCT) {
                  newt[xi][yi][zi] = missingvalue;
                }
              }
              progress++;
              if (progress % 50 == 0)
              {
                double p2 = 100.0D * progress / total;
                String format = "0.0";
                DecimalFormat intf = new DecimalFormat(format);
                if (p2 < 10.0D) {
                  format = "0.0";
                } else if (p2 < 100.0D) {
                  format = "00.0";
                } else {
                  format = "#00.0";
                }
                System.out.println("Progress: " + intf.format(p2) + "%" + " new val: " + newt[xi][yi][zi] + " empty octants: " + empty_octants + " " + zv[xi][yi][zi]);
              }
            }
          }
        }
      }
    }
    else
    {
      if (debug) {
        System.out.println("begin of loops - no Octant search!");
      }
      if ((search_x_new == 0.0D) && (search_y_new == 0.0D) && (search_z_new == 0.0D))
      {
        if (debug) {
          System.out.println("use all in every direction is - true");
        }
        for (int z = 0; z < nz; z++) {
          for (int y = 0; y < ny; y++) {
            for (int x = 0; x < nx; x++)
            {
              omega = 0.0D;tau = 0.0D;
              boolean b_identic = false;
              for (int i = 0; i < ni0; i++)
              {
                sum += 1L;
                if (sum % scr_progress == 0L) {
                  this.current = Math.round(sum * nr_of_indizes);
                }
                deltax = Math.pow(XC[i] - xv[x], 2.0D);
                deltay = Math.pow((YC[i] - yv[y]) * relation_y, 2.0D);
                deltaz = Math.pow((ZC[i] - zv[x][y][z]) * relation_z, 2.0D);
                double scattered_data_vecdist = Math.sqrt(deltax + deltay + deltaz);
                if (Math.abs(scattered_data_vecdist) < D_TOL)
                {
                  b_identic = true;
                  if (debug) {
                    System.out.println("identic " + Math.abs(scattered_data_vecdist));
                  }
                  newt[x][y][z] = VAL[i];
                  break;
                }
                vecdist = Math.sqrt(Math.pow(scattered_data_vecdist, 2.0D) + Math.pow(delta, 2.0D));
                omega += errorVal[i] * VAL[i] / Math.pow(vecdist, beta);
                tau += errorVal[i] * 1.0D / Math.pow(vecdist, beta);
              }
              if (!b_identic) {
                newt[x][y][z] = (omega / tau);
              }
            }
          }
        }
      }
      else
      {
        if (debug) {
          System.out.println("use all in every direction is - false");
        }
        double search_distance = Math.sqrt(Math.pow(wx, 2.0D) + Math.pow(wy * relation_y, 2.0D) + Math.pow(wz * relation_z, 2.0D));
        for (int z = 0; z < nz; z++) {
          for (int y = 0; y < ny; y++) {
            for (int x = 0; x < nx; x++)
            {
              omega = 0.0D;
              tau = 0.0D;
              scr11 = 0L;
              boolean b_identic = false;
              for (int i = 0; i < ni0; i++)
              {
                sum += 1L;
                if (sum % scr_progress == 0L) {
                  this.current = Math.round(sum * nr_of_indizes);
                }
                deltax = Math.pow(XC[i] - xv[x], 2.0D);
                deltay = Math.pow((YC[i] - yv[y]) * relation_y, 2.0D);
                deltaz = Math.pow((ZC[i] - zv[x][y][z]) * relation_z, 2.0D);
                double scattered_data_vecdist = Math.sqrt(deltax + deltay + deltaz);
                if (Math.abs(scattered_data_vecdist) < D_TOL)
                {
                  b_identic = true;
                  if (debug) {
                    System.out.println("identic " + Math.abs(scattered_data_vecdist));
                  }
                  newt[x][y][z] = VAL[i];
                  break;
                }
                double A = Math.pow(wx, 2.0D);
                double B = Math.pow(wy * relation_y, 2.0D);
                double C = Math.pow(wz * relation_z, 2.0D);
                double ellipsoid = deltax / A + deltay / B + deltaz / C;
                if (ellipsoid <= 1.0D)
                {
                  vecdist = Math.sqrt(Math.pow(scattered_data_vecdist, 2.0D) + Math.pow(delta, 2.0D));
                  
                  omega += errorVal[i] * VAL[i] / Math.pow(vecdist, beta);
                  tau += errorVal[i] * 1.0D / Math.pow(vecdist, beta);
                  scr11 += 1L;
                }
              }
              if (!b_identic)
              {
                newt[x][y][z] = (omega / tau);
                if (scr11 < assign_missing_value_when_lessdata_than)
                {
                  newt[x][y][z] = missingvalue;scr12 += 1L;
                }
              }
            }
          }
        }
      }
    }
    long end = System.currentTimeMillis();
    if (debug) {
      System.out.println("Calculation Time = " + (end - begin));
    }
    if (debug) {
      System.out.println("finished: Calciw3d - Nr of Missing Values = " + scr12);
    }
    if (b_trend)
    {
      trend.addTrendGrid(newt, xv, yv, zv, X1, X2, topofile, nx, ny, nz, missingvalue);
      if (debug) {
        System.out.println("Calciw3d: b_trend = " + b_trend + " addTrend");
      }
      writedata wd = new writedata(savefilename + ".teufe", xv, yv, zv0, trend.gridteufe);
      new saveResultsurferGrd(savefilename, nx, ny, nz, xv, yv, zv0, trend.gridteufe);
    }
    else
    {
      writedata wd = new writedata(savefilename + ".teufe", xv, yv, zv0, newt);
      new saveResultsurferGrd(savefilename, nx, ny, nz, xv, yv, zv0, newt);
    }
  }
  
  private double[][][] iw3d_useAll(boolean debug, int ni0, int nx, int ny, int nz, long scr_progress, double nr_of_indizes, double[] XC, double[] YC, double[] ZC, double[] xv, double[] yv, double[] zv, double[] VAL, double[] errorVal, double beta, double delta, double relation_y, double relation_z, double D_TOL)
  {
    if (debug) {
      System.out.println("use all in every direction is - true");
    }
    double omega = 0.0D;double tau = 0.0D;double sum = 0.0D;double vecdist = 0.0D;
    double deltax = 0.0D;double deltay = 0.0D;double deltaz = 0.0D;
    long current = 0L;
    double scattered_data_vecdist = 0.0D;
    double[][][] newt = new double[nx][ny][nz];
    for (int z = 0; z < nz; z++) {
      for (int y = 0; y < ny; y++) {
        for (int x = 0; x < nx; x++)
        {
          omega = 0.0D;tau = 0.0D;
          boolean b_identic = false;
          for (int i = 0; i < ni0; i++)
          {
            sum += 1.0D;
            if (sum % scr_progress == 0.0D) {
              current = Math.round(sum * nr_of_indizes);
            }
            deltax = Math.pow(XC[i] - xv[x], 2.0D);
            deltay = Math.pow((YC[i] - yv[y]) * relation_y, 2.0D);
            deltaz = Math.pow((ZC[i] - zv[z]) * relation_z, 2.0D);
            scattered_data_vecdist = Math.sqrt(deltax + deltay + deltaz);
            if (Math.abs(scattered_data_vecdist) < D_TOL)
            {
              b_identic = true;
              if (debug) {
                System.out.println("identic " + Math.abs(scattered_data_vecdist));
              }
              newt[x][y][z] = VAL[i];
              break;
            }
            vecdist = Math.sqrt(Math.pow(scattered_data_vecdist, 2.0D) + Math.pow(delta, 2.0D));
            omega += errorVal[i] * VAL[i] / Math.pow(vecdist, beta);
            tau += errorVal[i] * 1.0D / Math.pow(vecdist, beta);
          }
          if (!b_identic) {
            newt[x][y][z] = (omega / tau);
          }
        }
      }
    }
    return newt;
  }
  
  public void writeNearData(int nx, int ny, int nz, double[] XC, double[] YC, double[] ZC, int ni0, double[] xv, double[] yv, double[][][] zv, double wx, double wy, double wz)
  {
    double deltax = 0.0D;double deltay = 0.0D;double deltaz = 0.0D;
    double scattered_data_vecdist = 0.0D;
    int i2 = 0;
    
    double[][] data = new double[3][36212];
    
    System.out.println("nx*ny*nz*ni0 = " + nx * ny * nz * ni0);
    try
    {
      FileOutputStream out1 = new FileOutputStream("data.pos");
      BufferedOutputStream bout1 = new BufferedOutputStream(out1);
      PrintStream pout1 = new PrintStream(bout1);
      for (int z = 0; z < nz; z++) {
        for (int y = 0; y < ny; y++) {
          for (int x = 0; x < nx; x++) {
            for (int i = 0; i < ni0; i++)
            {
              deltax = Math.pow(XC[i] - xv[x], 2.0D);
              deltay = Math.pow(YC[i] - yv[y], 2.0D);
              deltaz = Math.pow(ZC[i] - zv[x][y][z], 2.0D);
              scattered_data_vecdist = Math.sqrt(deltax + deltay + deltaz);
              double A = Math.pow(wx, 2.0D);
              double B = Math.pow(wy, 2.0D);
              double C = Math.pow(wz, 2.0D);
              double ellipsoid = deltax / A + deltay / B + deltaz / C;
              if (ellipsoid <= 1.0D)
              {
                data[0][i2] = XC[i];
                data[1][i2] = YC[i];
                data[2][i2] = ZC[i];
                i2++;
              }
            }
          }
        }
      }
      double[][] newdata = new double[4][i2];
      for (int i = 0; i < i2; i++)
      {
        newdata[0][i] = Math.sqrt(Math.pow(data[0][i], 2.0D) + Math.pow(data[1][i], 2.0D) + Math.pow(data[2][i], 2.0D));
        for (int j = 1; j < 4; j++) {
          newdata[j][i] = data[(j - 1)][i];
        }
      }
      QickSortArray qsa = new QickSortArray();
      newdata = qsa.quicksort(newdata);
      for (int i = 0; i < i2 - 1; i++) {
        if ((newdata[1][i] != newdata[1][(i + 1)]) && (newdata[2][i] != newdata[2][(i + 1)]) && (newdata[3][i] != newdata[3][(i + 1)])) {
          pout1.println(newdata[1][i] + " " + newdata[2][i] + " " + newdata[3][i]);
        }
      }
      if ((newdata[1][(i2 - 2)] != newdata[1][(i2 - 1)]) && (newdata[2][(i2 - 2)] != newdata[2][(i2 - 1)]) && (newdata[3][(i2 - 2)] != newdata[3][(i2 - 1)])) {
        pout1.println(newdata[1][(i2 - 1)] + " " + newdata[2][(i2 - 1)] + " " + newdata[3][(i2 - 1)]);
      }
      pout1.close();
      bout1.close();
      out1.close();
    }
    catch (IOException ioe)
    {
      System.out.println(ioe.toString());
    }
  }
}



