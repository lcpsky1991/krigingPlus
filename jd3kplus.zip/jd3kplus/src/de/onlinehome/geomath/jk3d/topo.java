/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ 
/*   5:    */ public class topo
/*   6:    */ {
/*   7: 34 */   private int nc = 5;
/*   8: 36 */   private double[][] cluster_Rmin = new double[this.nc][this.nc];
/*   9: 37 */   private double[][] cluster_Rmax = new double[this.nc][this.nc];
/*  10: 38 */   private double[][] cluster_Hmin = new double[this.nc][this.nc];
/*  11: 39 */   private double[][] cluster_Hmax = new double[this.nc][this.nc];
/*  12:    */   private double[][][][] cdata;
/*  13: 42 */   private int[][] ncd = new int[this.nc][this.nc];
/*  14:    */   
/*  15:    */   public double getHeight(double Rechts, double Hoch)
/*  16:    */   {
/*  17: 47 */     double Dtol = 251.0D;
/*  18: 48 */     double z = -1.797693134862316E+308D;
/*  19: 51 */     for (int x = 0; x < this.nc; x++) {
/*  20: 52 */       for (int y = 0; y < this.nc; y++) {
/*  21: 53 */         if ((Rechts >= this.cluster_Rmin[x][y]) && (Rechts <= this.cluster_Rmax[x][y]) && (Hoch >= this.cluster_Hmin[x][y]) && (Hoch <= this.cluster_Hmax[x][y])) {
/*  22: 55 */           for (int ii = 0; ii <= this.ncd[x][y]; ii++)
/*  23:    */           {
/*  24: 56 */             double D = Math.sqrt(Math.pow(Rechts - this.cdata[x][y][ii][0], 2.0D) + Math.pow(Hoch - this.cdata[x][y][ii][1], 2.0D));
/*  25: 59 */             if (D < Dtol)
/*  26:    */             {
/*  27: 60 */               z = this.cdata[x][y][ii][2];
/*  28: 61 */               break;
/*  29:    */             }
/*  30:    */           }
/*  31:    */         }
/*  32:    */       }
/*  33:    */     }
/*  34: 67 */     return z;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void cluster2D(int nis, double[][] data)
/*  38:    */   {
/*  39: 75 */     double minx = 1.0E+064D;
/*  40: 76 */     double miny = minx;
/*  41: 77 */     double maxx = -1.0E+064D;
/*  42: 78 */     double maxy = maxx;
/*  43: 80 */     for (int ii = 0; ii <= nis; ii++)
/*  44:    */     {
/*  45: 81 */       minx = Math.min(data[ii][0], minx);
/*  46: 82 */       maxx = Math.max(data[ii][0], maxx);
/*  47: 83 */       miny = Math.min(data[ii][1], miny);
/*  48: 84 */       maxy = Math.max(data[ii][1], maxy);
/*  49:    */     }
/*  50: 87 */     double dx = maxx - minx;
/*  51: 88 */     double dy = maxy - miny;
/*  52:    */     
/*  53: 90 */     double tx = dx / this.nc;
/*  54: 91 */     double ty = dy / this.nc;
/*  55:    */     
/*  56: 93 */     double mx = minx;
/*  57: 94 */     for (int x = 0; x < this.nc; x++)
/*  58:    */     {
/*  59: 95 */       double my = miny;
/*  60: 96 */       for (int y = 0; y < this.nc; y++)
/*  61:    */       {
/*  62: 97 */         this.cluster_Rmin[x][y] = mx;
/*  63: 98 */         this.cluster_Hmin[x][y] = my;
/*  64: 99 */         this.cluster_Rmax[x][y] = (minx + (x + 1) * tx);
/*  65:100 */         this.cluster_Hmax[x][y] = (miny + (y + 1) * ty);
/*  66:101 */         my = miny + (y + 1) * ty;
/*  67:    */       }
/*  68:103 */       mx = minx + (x + 1) * tx;
/*  69:    */     }
/*  70:105 */     this.cdata = new double[this.nc][this.nc][2 * ((1 + nis) / (1 + this.nc * this.nc - this.nc))][3];
/*  71:106 */     System.out.println("nis = " + nis + " - " + 2 * ((1 + nis) / (1 + this.nc * this.nc - this.nc)));
/*  72:107 */     for (int ii = 0; ii <= nis; ii++) {
/*  73:108 */       for (x = 0; x < this.nc; x++) {
/*  74:109 */         for (int y = 0; y < this.nc; y++) {
/*  75:110 */           if ((data[ii][0] >= this.cluster_Rmin[x][y]) && (data[ii][0] <= this.cluster_Rmax[x][y]) && (data[ii][1] >= this.cluster_Hmin[x][y]) && (data[ii][1] <= this.cluster_Hmax[x][y]))
/*  76:    */           {
/*  77:112 */             this.cdata[x][y][this.ncd[x][y]][0] = data[ii][0];
/*  78:113 */             this.cdata[x][y][this.ncd[x][y]][1] = data[ii][1];
/*  79:114 */             this.cdata[x][y][this.ncd[x][y]][2] = data[ii][2];
/*  80:115 */             this.ncd[x][y] += 1;
/*  81:    */           }
/*  82:    */         }
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.topo
 * JD-Core Version:    0.7.0.1
 */