package de.onlinehome.geomath.jk3d;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.StreamTokenizer;
import java.util.Vector;

public class dgm
{
  private double[][] dDGMValues;
  private int i;
  private int j;
  private int count;
  private int ni_dgm;
  private int nj_dgm;
  private boolean debug = true;
  
  public void readDGM(String Directory, String Filename)
  {
    int maxc = 0;
    Vector v2 = new Vector();
    try
    {
      File f = new File(Directory + Filename);
      if (f.length() == 0L) {
        System.out.println("Sorry the file you selected has zero length: " + Directory + Filename);
      }
    }
    catch (NullPointerException exc)
    {
      System.out.println(exc);return;
    }
    try
    {
      FileInputStream fis = new FileInputStream(Directory + Filename);
      BufferedReader r = new BufferedReader(new InputStreamReader(fis));
      StreamTokenizer st = new StreamTokenizer(r);
      
      st.resetSyntax();
      st.whitespaceChars(32, 32);
      st.whitespaceChars(10, 10);
      st.whitespaceChars(9, 9);
      st.whitespaceChars(44, 44);
      st.whitespaceChars(59, 59);
      st.wordChars(48, 57);
      st.wordChars(101, 101);
      st.wordChars(69, 69);
      st.wordChars(46, 46);
      st.wordChars(43, 43);
      st.wordChars(45, 45);
      st.eolIsSignificant(true);
      

      r.readLine();
      while (st.nextToken() != -1)
      {
        if (this.i != st.lineno()) {
          this.count = 0;
        }
        String s1 = st.sval;
        if (s1 != null)
        {
          v2.addElement(s1);
          this.count += 1;
          this.i = st.lineno();
        }
        maxc = Math.max(this.count, maxc);
      }
    }
    catch (IOException ioe) {}
    this.ni_dgm = (this.i - 1);this.nj_dgm = (maxc - 1);
    if (this.debug) {
      System.out.println("v2.size() = " + v2.size() + " number_of_rows = " + (this.ni_dgm + 1) + " number_of_columns = " + (this.nj_dgm + 1));
    }
    this.dDGMValues = new double[this.ni_dgm + 1][this.nj_dgm + 1];
    int k = 0;
    for (this.i = 0; this.i <= this.ni_dgm; this.i += 1) {
      for (this.j = 0; this.j <= this.nj_dgm; this.j += 1)
      {
        Object f = v2.elementAt(k);
        String s = f.toString();
        
        this.dDGMValues[this.i][this.j] = Double.valueOf(s).doubleValue();
        k++;
      }
    }
    System.out.println("finished reading " + (this.ni_dgm + 1) + " rows with " + (this.nj_dgm + 1) + " columns from " + Filename);
    


    double minRE = 1.0E+064D;
    double maxRE = -1.0E+064D;
    double minHO = minRE;
    double maxHO = maxRE;
    for (this.i = 0; this.i <= this.ni_dgm; this.i += 1)
    {
      minRE = Math.min(this.dDGMValues[this.i][0], minRE);
      maxRE = Math.max(this.dDGMValues[this.i][0], maxRE);
      minHO = Math.min(this.dDGMValues[this.i][1], minHO);
      maxHO = Math.max(this.dDGMValues[this.i][1], maxHO);
    }
    System.out.println("minRE= " + minRE + "\nmaxRE= " + maxRE + "\nminHO= " + minHO + "\nmaxHO= " + maxHO);
  }
  
  int nr_dgm()
  {
    return this.ni_dgm;
  }
  
  double[][] dgm_values()
  {
    return this.dDGMValues;
  }
}



