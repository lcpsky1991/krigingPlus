/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import cern.jet.stat.Gamma;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ 
/*   6:    */ public class variogramModel
/*   7:    */ {
/*   8:    */   public double variogramModel(String variogramType, double nugget, double sill, double range, double distance)
/*   9:    */   {
/*  10: 42 */     double sv = 0.0D;
/*  11: 43 */     if (variogramType.equalsIgnoreCase("gaussian"))
/*  12:    */     {
/*  13: 44 */       sv = nugget + sill * (1.0D - Math.exp(-(Math.pow(3.0D * distance, 2.0D) / Math.pow(range, 2.0D))));
/*  14:    */     }
/*  15: 45 */     else if (variogramType.equalsIgnoreCase("spherical"))
/*  16:    */     {
/*  17: 46 */       if (distance <= range) {
/*  18: 47 */         sv = nugget + sill * (1.5D * distance / range - 0.5D * Math.pow(distance / range, 3.0D));
/*  19:    */       } else {
/*  20: 49 */         sv = nugget + sill * 1.0D;
/*  21:    */       }
/*  22:    */     }
/*  23: 51 */     else if (variogramType.equalsIgnoreCase("linear"))
/*  24:    */     {
/*  25: 52 */       if (distance <= range) {
/*  26: 53 */         sv = nugget + (sill - nugget) / range * distance;
/*  27:    */       } else {
/*  28: 55 */         sv = sill;
/*  29:    */       }
/*  30:    */     }
/*  31: 57 */     else if (variogramType.equalsIgnoreCase("exponentiell"))
/*  32:    */     {
/*  33: 58 */       sv = nugget + sill * (1.0D - Math.exp(-3.0D * distance / range));
/*  34:    */     }
/*  35: 59 */     else if (variogramType.equalsIgnoreCase("power"))
/*  36:    */     {
/*  37: 60 */       System.out.println("Variogram type 'power' not implemented yet! Exit!");
/*  38: 61 */       System.exit(0);
/*  39:    */     }
/*  40: 62 */     else if (variogramType.equalsIgnoreCase("hole_effect"))
/*  41:    */     {
/*  42: 63 */       System.out.println("Variogram type 'hole_effect' not implemented yet! Exit!");
/*  43: 64 */       System.exit(0);
/*  44:    */     }
/*  45: 65 */     else if (variogramType.equalsIgnoreCase("matern"))
/*  46:    */     {
/*  47: 70 */       double C = 0.0D;
/*  48: 71 */       double nue = 0.7D;
/*  49: 72 */       double A1 = Math.pow(2.0D, nue - 1.0D) * Gamma.gamma(nue);
/*  50: 73 */       double B = Math.pow(distance / range, nue);
/*  51: 74 */       if (distance > 0.0D) {
/*  52: 75 */         C = bessik(distance / range, nue);
/*  53:    */       }
/*  54: 77 */       sv = nugget + sill * (1.0D - 1.0D / A1 * B * C);
/*  55:    */     }
/*  56: 79 */     return -sv;
/*  57:    */   }
/*  58:    */   
/*  59: 82 */   double EPS = 1.0E-010D;
/*  60: 83 */   double FPMIN = 1.E-030D;
/*  61: 84 */   double MAXIT = 10000.0D;
/*  62: 85 */   double XMIN = 2.0D;
/*  63: 86 */   double PI = 3.141592653589793D;
/*  64:    */   
/*  65:    */   double bessik(double x, double xnu)
/*  66:    */   {
/*  67:103 */     if ((x <= 0.0D) || (xnu < 0.0D)) {
/*  68:103 */       System.out.println("bad arguments in bessik " + x + " " + xnu);
/*  69:    */     }
/*  70:104 */     int nl = (int)(xnu + 0.5D);
/*  71:105 */     double xmu = xnu - nl;
/*  72:106 */     double xmu2 = xmu * xmu;
/*  73:107 */     double xi = 1.0D / x;
/*  74:108 */     double xi2 = 2.0D * xi;
/*  75:109 */     double h = xnu * xi;
/*  76:110 */     if (h < this.FPMIN) {
/*  77:110 */       h = this.FPMIN;
/*  78:    */     }
/*  79:111 */     double b = xi2 * xnu;
/*  80:112 */     double d = 0.0D;
/*  81:113 */     double c = h;
/*  82:114 */     for (int i = 1; i <= this.MAXIT; i++)
/*  83:    */     {
/*  84:115 */       b += xi2;
/*  85:116 */       d = 1.0D / (b + d);
/*  86:117 */       c = b + 1.0D / c;
/*  87:118 */       double del = c * d;
/*  88:119 */       h = del * h;
/*  89:120 */       if (Math.abs(del - 1.0D) < this.EPS) {
/*  90:    */         break;
/*  91:    */       }
/*  92:    */     }
/*  93:123 */     double ril = this.FPMIN;
/*  94:124 */     double ripl = h * ril;
/*  95:125 */     double ril1 = ril;
/*  96:126 */     double rip1 = ripl;
/*  97:127 */     double fact = xnu * xi;
/*  98:128 */     for (int l = nl; l >= 1; l--)
/*  99:    */     {
/* 100:129 */       double ritemp = fact * ril + ripl;
/* 101:130 */       fact -= xi;
/* 102:131 */       ripl = fact * ritemp + ril;
/* 103:132 */       ril = ritemp;
/* 104:    */     }
/* 105:134 */     double f = ripl / ril;
/* 106:    */     double rk1;
/* 107:    */     double rkmu;
/* 108:    */     double rk1;
/* 109:135 */     if (x < this.XMIN)
/* 110:    */     {
/* 111:136 */       double x2 = 0.5D * x;
/* 112:137 */       double pimu = this.PI * xmu;
/* 113:138 */       fact = Math.abs(pimu) < this.EPS ? 1.0D : pimu / Math.sin(pimu);
/* 114:139 */       d = -Math.log(x2);
/* 115:140 */       double e = xmu * d;
/* 116:141 */       double fact2 = Math.abs(e) < this.EPS ? 1.0D : Math.sinh(e) / e;
/* 117:    */       
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:149 */       double[] c1 = { -1.142022680371172D, 0.006516511267076D, 0.000308709017308D, -3.470626964E-006D, 6.943764E-009D, 3.678E-011D, -1.36E-013D };
/* 125:    */       
/* 126:    */ 
/* 127:    */ 
/* 128:153 */       double[] c2 = { 1.843740587300906D, -0.076852840844786D, 0.001271927136655D, -4.971736704E-006D, -3.312612E-008D, 2.4231E-010D, -1.7E-013D, -1.E-015D };
/* 129:    */       
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:158 */       double xx = 8.0D * xmu * xmu - 1.0D;
/* 134:159 */       double gam1 = chebev(-1.0D, 1.0D, c1, 5, xx);
/* 135:160 */       double gam2 = chebev(-1.0D, 1.0D, c2, 5, xx);
/* 136:161 */       double gampl = gam2 - xmu * gam1;
/* 137:162 */       double gammi = gam2 + xmu * gam1;
/* 138:    */       
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:168 */       double ff = fact * (gam1 * Math.cosh(e) + gam2 * fact2 * d);
/* 144:169 */       double sum = ff;
/* 145:170 */       e = Math.exp(e);
/* 146:171 */       double p = 0.5D * e / gampl;
/* 147:172 */       double q = 0.5D / (e * gammi);
/* 148:173 */       c = 1.0D;
/* 149:174 */       d = x2 * x2;
/* 150:175 */       double sum1 = p;
/* 151:176 */       for (i = 1; i <= this.MAXIT; i++)
/* 152:    */       {
/* 153:177 */         ff = (i * ff + p + q) / (i * i - xmu2);
/* 154:178 */         c *= d / i;
/* 155:179 */         p /= (i - xmu);
/* 156:180 */         q /= (i + xmu);
/* 157:181 */         double del = c * ff;
/* 158:182 */         sum += del;
/* 159:183 */         double del1 = c * (p - i * ff);
/* 160:184 */         sum1 += del1;
/* 161:185 */         if (Math.abs(del) < Math.abs(sum) * this.EPS) {
/* 162:    */           break;
/* 163:    */         }
/* 164:    */       }
/* 165:187 */       if (i > this.MAXIT) {
/* 166:187 */         System.out.println("bessk series failed to converge");
/* 167:    */       }
/* 168:188 */       double rkmu = sum;
/* 169:189 */       rk1 = sum1 * xi2;
/* 170:    */     }
/* 171:    */     else
/* 172:    */     {
/* 173:191 */       b = 2.0D * (1.0D + x);
/* 174:192 */       d = 1.0D / b;
/* 175:    */       double delh;
/* 176:193 */       h = delh = d;
/* 177:194 */       double q1 = 0.0D;
/* 178:195 */       double q2 = 1.0D;
/* 179:196 */       double a1 = 0.25D - xmu2;
/* 180:197 */       double q = c = a1;
/* 181:198 */       double a = -a1;
/* 182:199 */       double s = 1.0D + q * delh;
/* 183:200 */       for (i = 2; i <= this.MAXIT; i++)
/* 184:    */       {
/* 185:201 */         a -= 2 * (i - 1);
/* 186:202 */         c = -a * c / i;
/* 187:203 */         double qnew = (q1 - b * q2) / a;
/* 188:204 */         q1 = q2;
/* 189:205 */         q2 = qnew;
/* 190:206 */         q += c * qnew;
/* 191:207 */         b += 2.0D;
/* 192:208 */         d = 1.0D / (b + a * d);
/* 193:209 */         delh = (b * d - 1.0D) * delh;
/* 194:210 */         h += delh;
/* 195:211 */         double dels = q * delh;
/* 196:212 */         s += dels;
/* 197:213 */         if (Math.abs(dels / s) < this.EPS) {
/* 198:    */           break;
/* 199:    */         }
/* 200:    */       }
/* 201:215 */       if (i > this.MAXIT) {
/* 202:215 */         System.out.println("bessik: failure to converge in cf2");
/* 203:    */       }
/* 204:216 */       h = a1 * h;
/* 205:217 */       rkmu = Math.sqrt(this.PI / (2.0D * x)) * Math.exp(-x) / s;
/* 206:218 */       rk1 = rkmu * (xmu + x + 0.5D - h) * xi;
/* 207:    */     }
/* 208:220 */     double rkmup = xmu * xi * rkmu - rk1;
/* 209:221 */     double rimu = xi / (f * rkmu - rkmup);
/* 210:222 */     double ri = rimu * ril1 / ril;
/* 211:223 */     double rip = rimu * rip1 / ril;
/* 212:224 */     for (i = 1; i <= nl; i++)
/* 213:    */     {
/* 214:225 */       double rktemp = (xmu + i) * xi2 * rk1 + rkmu;
/* 215:226 */       rkmu = rk1;
/* 216:227 */       rk1 = rktemp;
/* 217:    */     }
/* 218:229 */     double rk = rkmu;
/* 219:230 */     double rkp = xnu * xi * rkmu - rk1;
/* 220:    */     
/* 221:232 */     return rkp;
/* 222:    */   }
/* 223:    */   
/* 224:    */   double chebev(double a, double b, double[] c, int m, double x)
/* 225:    */   {
/* 226:238 */     double d = 0.0D;double dd = 0.0D;
/* 227:240 */     if ((x - a) * (x - b) > 0.0D) {
/* 228:240 */       System.out.println("x not in range in routine chebev");
/* 229:    */     }
/* 230:    */     double y;
/* 231:241 */     double y2 = 2.0D * (y = (2.0D * x - a - b) / (b - a));
/* 232:242 */     for (int j = m - 1; j >= 1; j--)
/* 233:    */     {
/* 234:243 */       double sv = d;
/* 235:244 */       d = y2 * d - dd + c[j];
/* 236:245 */       dd = sv;
/* 237:    */     }
/* 238:247 */     return y * d - dd + 0.5D * c[0];
/* 239:    */   }
/* 240:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.variogramModel
 * JD-Core Version:    0.7.0.1
 */