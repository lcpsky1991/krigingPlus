/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.awt.FileDialog;
/*   4:    */ import java.awt.Frame;
/*   5:    */ import java.io.BufferedOutputStream;
/*   6:    */ import java.io.FileOutputStream;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ 
/*  10:    */ public class saveResultsurferGrd
/*  11:    */   extends Frame
/*  12:    */ {
/*  13:    */   int x;
/*  14:    */   int y;
/*  15:    */   int z;
/*  16:    */   private static final double MAX_VAL = 1.0E+064D;
/*  17:    */   private static final double MIN_VAL = -1.0E+064D;
/*  18:    */   private static final double MISSING_VALUE = 1.70141E+038D;
/*  19:    */   
/*  20:    */   public saveResultsurferGrd(String filename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] result)
/*  21:    */   {
/*  22:    */     String Directory;
/*  23:    */     String SaveFilename;
/*  24: 50 */     if (filename == null)
/*  25:    */     {
/*  26: 51 */       FileDialog d = new FileDialog(this, "Save File", 1);
/*  27: 52 */       d.setVisible(true);
/*  28: 53 */       String Directory = d.getDirectory();
/*  29: 54 */       String SaveFilename = d.getFile();
/*  30: 55 */       d.dispose();
/*  31:    */     }
/*  32:    */     else
/*  33:    */     {
/*  34: 57 */       Directory = "";
/*  35: 58 */       SaveFilename = filename;
/*  36:    */     }
/*  37: 60 */     Save(Directory, SaveFilename, nx, ny, nz, xv, yv, zv, result);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void Save(String Directory, String SaveFilename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] result)
/*  41:    */   {
/*  42: 66 */     double minx = xv[0];
/*  43: 67 */     double maxx = xv[(nx - 1)];
/*  44: 68 */     double miny = yv[0];
/*  45: 69 */     double maxy = yv[(ny - 1)];
/*  46: 70 */     double minz = zv[0];
/*  47: 71 */     double maxz = zv[(nz - 1)];
/*  48:    */     
/*  49:    */ 
/*  50: 74 */     double tmp_scale_x = 1.0D;
/*  51: 75 */     double multi_x = 1.0D;
/*  52: 76 */     for (double a = -30.0D; a < 30.0D; a += 1.0D)
/*  53:    */     {
/*  54: 77 */       tmp_scale_x = Math.pow(10.0D, a);
/*  55: 78 */       if (Math.abs(maxz - minz) <= tmp_scale_x)
/*  56:    */       {
/*  57: 79 */         multi_x = tmp_scale_x * 10.0D;
/*  58: 80 */         break;
/*  59:    */       }
/*  60:    */     }
/*  61: 84 */     System.out.println("nx,ny,nz: " + nx + " " + ny + " " + nz + " " + minx + " " + maxx + " " + miny + " " + maxy + " " + minz + " " + maxz);
/*  62:    */     try
/*  63:    */     {
/*  64: 87 */       FileOutputStream out1 = new FileOutputStream(Directory + SaveFilename);
/*  65: 88 */       BufferedOutputStream bout1 = new BufferedOutputStream(out1);
/*  66: 89 */       PrintStream pout1 = new PrintStream(bout1);
/*  67: 90 */       for (this.z = 0; this.z < nz; this.z += 1) {
/*  68: 91 */         for (this.y = 0; this.y < ny; this.y += 1) {
/*  69: 92 */           for (this.x = 0; this.x < nx; this.x += 1) {
/*  70: 93 */             pout1.println(xv[this.x] + " " + yv[this.y] + " " + zv[this.z] + " " + result[this.x][this.y][this.z]);
/*  71:    */           }
/*  72:    */         }
/*  73:    */       }
/*  74: 97 */       pout1.close();
/*  75: 98 */       bout1.close();
/*  76: 99 */       out1.close();
/*  77:    */     }
/*  78:    */     catch (IOException ioe)
/*  79:    */     {
/*  80:101 */       System.out.println(ioe.toString());
/*  81:    */     }
/*  82:104 */     for (this.z = 0; this.z < nz; this.z += 1)
/*  83:    */     {
/*  84:    */       long depth;
/*  85:    */       long depth;
/*  86:105 */       if (Math.abs(maxz - minz) > 10.0D) {
/*  87:106 */         depth = zv[this.z];
/*  88:    */       } else {
/*  89:109 */         depth = (zv[this.z] * multi_x);
/*  90:    */       }
/*  91:    */       try
/*  92:    */       {
/*  93:112 */         FileOutputStream out2 = new FileOutputStream(Directory + "_depth=" + depth + "_" + SaveFilename + ".grd");
/*  94:113 */         BufferedOutputStream bout2 = new BufferedOutputStream(out2);
/*  95:114 */         PrintStream pout2 = new PrintStream(bout2);
/*  96:    */         
/*  97:116 */         double minf = 1.0E+064D;
/*  98:117 */         double maxf = -1.0E+064D;
/*  99:118 */         for (this.x = 0; this.x < nx; this.x += 1) {
/* 100:119 */           for (this.y = 0; this.y < ny; this.y += 1) {
/* 101:120 */             if (result[this.x][this.y][this.z] != 1.70141E+038D)
/* 102:    */             {
/* 103:121 */               minf = Math.min(minf, result[this.x][this.y][this.z]);
/* 104:122 */               maxf = Math.max(maxf, result[this.x][this.y][this.z]);
/* 105:    */             }
/* 106:    */           }
/* 107:    */         }
/* 108:127 */         pout2.println("DSAA");
/* 109:128 */         pout2.println(nx + " " + ny);
/* 110:129 */         pout2.println(minx + " " + maxx);
/* 111:130 */         pout2.println(miny + " " + maxy);
/* 112:131 */         pout2.println(minf + " " + maxf);
/* 113:133 */         for (this.y = 0; this.y < ny; this.y += 1)
/* 114:    */         {
/* 115:134 */           for (this.x = 0; this.x < nx; this.x += 1) {
/* 116:135 */             pout2.print(result[this.x][this.y][this.z] + " ");
/* 117:    */           }
/* 118:137 */           pout2.println("");
/* 119:138 */           pout2.println("");
/* 120:    */         }
/* 121:140 */         pout2.close();
/* 122:141 */         bout2.close();
/* 123:142 */         out2.close();
/* 124:    */       }
/* 125:    */       catch (IOException ioe)
/* 126:    */       {
/* 127:144 */         System.out.println(ioe.toString());
/* 128:    */       }
/* 129:    */     }
/* 130:    */   }
/* 131:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.saveResultsurferGrd
 * JD-Core Version:    0.7.0.1
 */