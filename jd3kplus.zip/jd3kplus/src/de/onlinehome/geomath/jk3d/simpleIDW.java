/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ public class simpleIDW
/*  4:   */ {
/*  5:   */   static final long serialVersionUID = 22L;
/*  6:   */   
/*  7:   */   public double simpleIDW(double xv, double yv, double zv, int ni, double[][] ked)
/*  8:   */   {
/*  9:38 */     double sum1 = 0.0D;
/* 10:39 */     double sum2 = 0.0D;
/* 11:40 */     for (int i = 0; i < ni; i++)
/* 12:   */     {
/* 13:41 */       double dist = Math.sqrt(Math.pow(ked[i][0] - xv, 2.0D) + Math.pow(ked[i][1] - yv, 2.0D) + Math.pow(ked[i][2] - zv, 2.0D));
/* 14:42 */       if (dist == 0.0D)
/* 15:   */       {
/* 16:43 */         sum1 = ked[i][3];
/* 17:44 */         sum2 = 1.0D;
/* 18:45 */         break;
/* 19:   */       }
/* 20:47 */       sum1 += ked[i][3] / Math.pow(dist, 2.0D);
/* 21:48 */       sum2 += 1.0D / Math.pow(dist, 2.0D);
/* 22:   */     }
/* 23:50 */     double val = sum1 / sum2;
/* 24:51 */     return val;
/* 25:   */   }
/* 26:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.simpleIDW
 * JD-Core Version:    0.7.0.1
 */