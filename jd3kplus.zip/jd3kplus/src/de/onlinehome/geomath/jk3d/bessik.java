package de.onlinehome.geomath.jk3d;

import java.io.PrintStream;

public class bessik
{
  double EPS = 1.0E-010D;
  double FPMIN = 1.E-030D;
  double MAXIT = 10000.0D;
  double XMIN = 2.0D;
  double PI = 3.141592653589793D;
  
  double bessik(double x, double xnu)
  {
    if ((x <= 0.0D) || (xnu < 0.0D)) {
      System.out.println("bad arguments in bessik");
    }
    int nl = (int)(xnu + 0.5D);
    double xmu = xnu - nl;
    double xmu2 = xmu * xmu;
    double xi = 1.0D / x;
    double xi2 = 2.0D * xi;
    double h = xnu * xi;
    if (h < this.FPMIN) {
      h = this.FPMIN;
    }
    double b = xi2 * xnu;
    double d = 0.0D;
    double c = h;
    for (int i = 1; i <= this.MAXIT; i++)
    {
      b += xi2;
      d = 1.0D / (b + d);
      c = b + 1.0D / c;
      double del = c * d;
      h = del * h;
      if (Math.abs(del - 1.0D) < this.EPS) {
        break;
      }
    }
    if (i > this.MAXIT) {
      System.out.println("x too large in bessik; try asymptotic expansion");
    }
    double ril = this.FPMIN;
    double ripl = h * ril;
    double ril1 = ril;
    double rip1 = ripl;
    double fact = xnu * xi;
    for (int l = nl; l >= 1; l--)
    {
      double ritemp = fact * ril + ripl;
      fact -= xi;
      ripl = fact * ritemp + ril;
      ril = ritemp;
    }
    double f = ripl / ril;
    double rk1;
    double rkmu;
    double rk1;
    if (x < this.XMIN)
    {
      double x2 = 0.5D * x;
      double pimu = this.PI * xmu;
      fact = Math.abs(pimu) < this.EPS ? 1.0D : pimu / Math.sin(pimu);
      d = -Math.log(x2);
      double e = xmu * d;
      double fact2 = Math.abs(e) < this.EPS ? 1.0D : Math.sinh(e) / e;
      






      double[] c1 = { -1.142022680371172D, 0.006516511267076D, 0.000308709017308D, -3.470626964E-006D, 6.943764E-009D, 3.678E-011D, -1.36E-013D };
      


      double[] c2 = { 1.843740587300906D, -0.076852840844786D, 0.001271927136655D, -4.971736704E-006D, -3.312612E-008D, 2.4231E-010D, -1.7E-013D, -1.E-015D };
      



      double xx = 8.0D * xmu * xmu - 1.0D;
      double gam1 = chebev(-1.0D, 1.0D, c1, 5, xx);
      double gam2 = chebev(-1.0D, 1.0D, c2, 5, xx);
      double gampl = gam2 - xmu * gam1;
      double gammi = gam2 + xmu * gam1;
      




      double ff = fact * (gam1 * Math.cosh(e) + gam2 * fact2 * d);
      double sum = ff;
      e = Math.exp(e);
      double p = 0.5D * e / gampl;
      double q = 0.5D / (e * gammi);
      c = 1.0D;
      d = x2 * x2;
      double sum1 = p;
      for (i = 1; i <= this.MAXIT; i++)
      {
        ff = (i * ff + p + q) / (i * i - xmu2);
        c *= d / i;
        p /= (i - xmu);
        q /= (i + xmu);
        double del = c * ff;
        sum += del;
        double del1 = c * (p - i * ff);
        sum1 += del1;
        if (Math.abs(del) < Math.abs(sum) * this.EPS) {
          break;
        }
      }
      if (i > this.MAXIT) {
        System.out.println("bessk series failed to converge");
      }
      double rkmu = sum;
      rk1 = sum1 * xi2;
    }
    else
    {
      b = 2.0D * (1.0D + x);
      d = 1.0D / b;
      double delh;
      h = delh = d;
      double q1 = 0.0D;
      double q2 = 1.0D;
      double a1 = 0.25D - xmu2;
      double q = c = a1;
      double a = -a1;
      double s = 1.0D + q * delh;
      for (i = 2; i <= this.MAXIT; i++)
      {
        a -= 2 * (i - 1);
        c = -a * c / i;
        double qnew = (q1 - b * q2) / a;
        q1 = q2;
        q2 = qnew;
        q += c * qnew;
        b += 2.0D;
        d = 1.0D / (b + a * d);
        delh = (b * d - 1.0D) * delh;
        h += delh;
        double dels = q * delh;
        s += dels;
        if (Math.abs(dels / s) < this.EPS) {
          break;
        }
      }
      if (i > this.MAXIT) {
        System.out.println("bessik: failure to converge in cf2");
      }
      h = a1 * h;
      rkmu = Math.sqrt(this.PI / (2.0D * x)) * Math.exp(-x) / s;
      rk1 = rkmu * (xmu + x + 0.5D - h) * xi;
    }
    double rkmup = xmu * xi * rkmu - rk1;
    double rimu = xi / (f * rkmu - rkmup);
    double ri = rimu * ril1 / ril;
    double rip = rimu * rip1 / ril;
    for (i = 1; i <= nl; i++)
    {
      double rktemp = (xmu + i) * xi2 * rk1 + rkmu;
      rkmu = rk1;
      rk1 = rktemp;
    }
    double rk = rkmu;
    double rkp = xnu * xi * rkmu - rk1;
    
    return rkp;
  }
  
  double chebev(double a, double b, double[] c, int m, double x)
  {
    double d = 0.0D;double dd = 0.0D;
    if ((x - a) * (x - b) > 0.0D) {
      System.out.println("x not in range in routine chebev");
    }
    double y;
    double y2 = 2.0D * (y = (2.0D * x - a - b) / (b - a));
    for (int j = m - 1; j >= 1; j--)
    {
      double sv = d;
      d = y2 * d - dd + c[j];
      dd = sv;
    }
    return y * d - dd + 0.5D * c[0];
  }
}



