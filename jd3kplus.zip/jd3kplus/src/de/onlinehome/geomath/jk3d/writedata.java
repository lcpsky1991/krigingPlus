/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ import java.io.BufferedOutputStream;
/*  4:   */ import java.io.FileOutputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.PrintStream;
/*  7:   */ 
/*  8:   */ public class writedata
/*  9:   */ {
/* 10:   */   public writedata(String SaveFilename, double[] xv, double[] yv, double[] zv, double[][][] result)
/* 11:   */   {
/* 12:40 */     int nx = result.length;
/* 13:41 */     int ny = result[1].length;
/* 14:42 */     int nz = result[1][1].length;
/* 15:43 */     System.out.println("writedata - nx,ny,nz: " + nx + " " + ny + " " + nz);
/* 16:   */     try
/* 17:   */     {
/* 18:45 */       FileOutputStream out1 = new FileOutputStream(SaveFilename);
/* 19:46 */       BufferedOutputStream bout1 = new BufferedOutputStream(out1);
/* 20:47 */       PrintStream pout1 = new PrintStream(bout1);
/* 21:48 */       for (int z = 0; z < nz; z++) {
/* 22:49 */         for (int y = 0; y < ny; y++) {
/* 23:50 */           for (int x = 0; x < nx; x++) {
/* 24:52 */             if (result[x][y][z] == 1.70141E+038D) {
/* 25:53 */               pout1.println(xv[x] + " " + yv[y] + " NaN");
/* 26:   */             } else {
/* 27:55 */               pout1.println(xv[x] + " " + yv[y] + " " + result[x][y][z]);
/* 28:   */             }
/* 29:   */           }
/* 30:   */         }
/* 31:   */       }
/* 32:60 */       pout1.close();
/* 33:61 */       bout1.close();
/* 34:62 */       out1.close();
/* 35:   */     }
/* 36:   */     catch (IOException ioe)
/* 37:   */     {
/* 38:64 */       System.out.println(ioe.toString());
/* 39:   */     }
/* 40:   */   }
/* 41:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.writedata
 * JD-Core Version:    0.7.0.1
 */