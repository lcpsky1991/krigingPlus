/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.awt.FileDialog;
/*   4:    */ import java.awt.Frame;
/*   5:    */ import java.io.BufferedOutputStream;
/*   6:    */ import java.io.FileOutputStream;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.text.DecimalFormat;
/*  10:    */ 
/*  11:    */ public class saveResultTecplot
/*  12:    */   extends Frame
/*  13:    */ {
/*  14:    */   int x;
/*  15:    */   int y;
/*  16:    */   int z;
/*  17:    */   
/*  18:    */   public saveResultTecplot(String directory, String filename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] result)
/*  19:    */   {
/*  20:    */     String SaveDirectory;
/*  21:    */     String SaveFilename;
/*  22: 45 */     if (filename == null)
/*  23:    */     {
/*  24: 46 */       FileDialog d = new FileDialog(this, "Save File", 1);
/*  25: 47 */       d.setVisible(true);
/*  26: 48 */       String SaveDirectory = d.getDirectory();
/*  27: 49 */       String SaveFilename = d.getFile();
/*  28: 50 */       d.dispose();
/*  29:    */     }
/*  30:    */     else
/*  31:    */     {
/*  32: 52 */       SaveDirectory = directory;
/*  33: 53 */       SaveFilename = filename;
/*  34:    */     }
/*  35: 55 */     saveTecplot(SaveDirectory, SaveFilename, nx, ny, nz, xv, yv, zv, result);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void saveTecplot(String Directory, String SaveFilename, int nx, int ny, int nz, double[] xv, double[] yv, double[] zv, double[][][] result)
/*  39:    */   {
/*  40:    */     try
/*  41:    */     {
/*  42: 68 */       FileOutputStream out = new FileOutputStream(Directory + SaveFilename);
/*  43: 69 */       BufferedOutputStream bout = new BufferedOutputStream(out);
/*  44: 70 */       PrintStream pout = new PrintStream(bout);
/*  45:    */       
/*  46: 72 */       pout.println("TITLE = 'Interpolated Value'");
/*  47: 73 */       pout.println("VARIABLES = 'X','Y','Z','Value'");
/*  48: 74 */       String format = "00";
/*  49: 75 */       DecimalFormat intf = new DecimalFormat(format);
/*  50: 77 */       if ((nx < 10) && (ny < 10) && (nz < 10)) {
/*  51: 78 */         format = "0";
/*  52: 80 */       } else if ((nx < 100) && (ny < 100) && (nz < 100)) {
/*  53: 81 */         format = "00";
/*  54:    */       } else {
/*  55: 84 */         format = "#00";
/*  56:    */       }
/*  57: 86 */       pout.print("ZONE I=");
/*  58:    */       
/*  59: 88 */       pout.print(nx);
/*  60: 89 */       pout.print(", J=");
/*  61:    */       
/*  62: 91 */       pout.print(ny);
/*  63: 92 */       pout.print(", K=");
/*  64:    */       
/*  65: 94 */       pout.print(nz);
/*  66: 95 */       pout.print(", F=POINT\n");
/*  67: 98 */       for (this.z = 0; this.z < nz; this.z += 1) {
/*  68: 99 */         for (this.y = 0; this.y < ny; this.y += 1) {
/*  69:100 */           for (this.x = 0; this.x < nx; this.x += 1) {
/*  70:101 */             pout.println(xv[this.x] + "\t" + yv[this.y] + "\t" + zv[this.z] + "\t" + result[this.x][this.y][this.z]);
/*  71:    */           }
/*  72:    */         }
/*  73:    */       }
/*  74:105 */       pout.close();
/*  75:106 */       bout.close();
/*  76:107 */       out.close();
/*  77:    */     }
/*  78:    */     catch (IOException ioe)
/*  79:    */     {
/*  80:110 */       System.out.println(ioe.toString());
/*  81:    */     }
/*  82:    */   }
/*  83:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.saveResultTecplot
 * JD-Core Version:    0.7.0.1
 */