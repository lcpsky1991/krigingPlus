/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ 
/*  5:   */ public class reduceArea
/*  6:   */ {
/*  7:34 */   private int ninew = 0;
/*  8:   */   private double[][] datanew;
/*  9:   */   
/* 10:   */   public reduceArea(double x0, double x1, double y0, double y1, double z0, double z1, int ni0, double[][] data)
/* 11:   */   {
/* 12:38 */     this.datanew = new double[ni0][data[1].length];
/* 13:39 */     this.ninew = ni0;
/* 14:40 */     int i2 = 0;
/* 15:41 */     for (int i = 0; i < ni0; i++) {
/* 16:42 */       if ((data[i][0] >= x0) && (data[i][0] <= x1) && (data[i][1] >= y0) && (data[i][1] <= y1) && (data[i][2] >= z0) && (data[i][2] <= z1))
/* 17:   */       {
/* 18:45 */         for (int m = 0; m < data[1].length; m++) {
/* 19:46 */           this.datanew[i2][m] = data[i][m];
/* 20:   */         }
/* 21:48 */         i2++;
/* 22:   */       }
/* 23:   */       else
/* 24:   */       {
/* 25:50 */         this.ninew -= 1;
/* 26:   */       }
/* 27:   */     }
/* 28:53 */     setData(this.datanew);
/* 29:54 */     System.out.print("after: " + this.ninew);
/* 30:55 */     System.out.print("... removed " + (ni0 - this.ninew) + " values\n");
/* 31:   */   }
/* 32:   */   
/* 33:   */   private void setData(double[][] data)
/* 34:   */   {
/* 35:59 */     this.datanew = data;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public double[][] data()
/* 39:   */   {
/* 40:62 */     return this.datanew;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public int ni()
/* 44:   */   {
/* 45:65 */     return this.ninew;
/* 46:   */   }
/* 47:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.reduceArea
 * JD-Core Version:    0.7.0.1
 */