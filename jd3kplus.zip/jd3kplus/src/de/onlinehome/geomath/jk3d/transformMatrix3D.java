/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ import Jama.Matrix;
/*  4:   */ 
/*  5:   */ public class transformMatrix3D
/*  6:   */ {
/*  7:39 */   private Matrix tMatrix = new Matrix(3, 3);
/*  8:   */   
/*  9:   */   public transformMatrix3D(double a_hmax, double a_hmin, double a_vert)
/* 10:   */   {
/* 11:42 */     tMatrix3D(a_hmax, a_hmin, a_vert);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void tMatrix3D(double a_hmax, double a_hmin, double a_vert)
/* 15:   */   {
/* 16:46 */     this.tMatrix.set(0, 0, 1.0D / a_hmax);this.tMatrix.set(1, 0, 0.0D);this.tMatrix.set(2, 0, 0.0D);
/* 17:47 */     this.tMatrix.set(0, 1, 0.0D);this.tMatrix.set(1, 1, 1.0D / a_hmin);this.tMatrix.set(2, 1, 0.0D);
/* 18:48 */     this.tMatrix.set(0, 2, 0.0D);this.tMatrix.set(1, 2, 0.0D);this.tMatrix.set(2, 2, 1.0D / a_vert);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Matrix transfMatrix3D()
/* 22:   */   {
/* 23:51 */     return this.tMatrix;
/* 24:   */   }
/* 25:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.transformMatrix3D
 * JD-Core Version:    0.7.0.1
 */