/*  1:   */ package de.onlinehome.geomath.jk3d;
/*  2:   */ 
/*  3:   */ import Jama.Matrix;
/*  4:   */ import Jama.SingularValueDecomposition;
/*  5:   */ 
/*  6:   */ public class Matrices
/*  7:   */ {
/*  8:14 */   public static double MACHEPS = 2.0E-016D;
/*  9:   */   
/* 10:   */   public static void updateMacheps()
/* 11:   */   {
/* 12:20 */     MACHEPS = 1.0D;
/* 13:   */     do
/* 14:   */     {
/* 15:22 */       MACHEPS /= 2.0D;
/* 16:23 */     } while (1.0D + MACHEPS / 2.0D != 1.0D);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static Matrix pinv(Matrix x)
/* 20:   */   {
/* 21:32 */     if (x.rank() < 1) {
/* 22:33 */       return null;
/* 23:   */     }
/* 24:34 */     if (x.getColumnDimension() > x.getRowDimension()) {
/* 25:35 */       return pinv(x.transpose()).transpose();
/* 26:   */     }
/* 27:36 */     SingularValueDecomposition svdX = new SingularValueDecomposition(x);
/* 28:37 */     double[] singularValues = svdX.getSingularValues();
/* 29:38 */     double tol = Math.max(x.getColumnDimension(), x.getRowDimension()) * singularValues[0] * MACHEPS;
/* 30:39 */     double[] singularValueReciprocals = new double[singularValues.length];
/* 31:40 */     for (int i = 0; i < singularValues.length; i++) {
/* 32:41 */       singularValueReciprocals[i] = (Math.abs(singularValues[i]) < tol ? 0.0D : 1.0D / singularValues[i]);
/* 33:   */     }
/* 34:42 */     double[][] u = svdX.getU().getArray();
/* 35:43 */     double[][] v = svdX.getV().getArray();
/* 36:44 */     int min = Math.min(x.getColumnDimension(), u[0].length);
/* 37:45 */     double[][] inverse = new double[x.getColumnDimension()][x.getRowDimension()];
/* 38:46 */     for (int i = 0; i < x.getColumnDimension(); i++) {
/* 39:47 */       for (int j = 0; j < u.length; j++) {
/* 40:48 */         for (int k = 0; k < min; k++) {
/* 41:49 */           inverse[i][j] += v[i][k] * singularValueReciprocals[k] * u[j][k];
/* 42:   */         }
/* 43:   */       }
/* 44:   */     }
/* 45:50 */     return new Matrix(inverse);
/* 46:   */   }
/* 47:   */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.Matrices
 * JD-Core Version:    0.7.0.1
 */