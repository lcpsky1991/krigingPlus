/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ 
/*   5:    */ public class trend
/*   6:    */ {
/*   7:    */   public static double[][][] gridteufe;
/*   8:    */   static final long serialVersionUID = 22L;
/*   9:    */   
/*  10:    */   public void trend() {}
/*  11:    */   
/*  12:    */   public static double[] removeTrend(double[] temp, double[] de, double X1, double X2, int ni)
/*  13:    */   {
/*  14: 46 */     System.out.println("removeTrend: X1 = " + X1 + " X2 = " + X2);
/*  15: 47 */     for (int i = 0; i <= ni; i++) {
/*  16: 48 */       temp[i] = ((temp[i] - X1) / (X2 * de[i]));
/*  17:    */     }
/*  18: 50 */     return temp;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static double[][][] addTrend(double[][][] newt, double[] zv, double X1, double X2, int nx, int ny, int nz, double missingvalue)
/*  22:    */   {
/*  23: 56 */     System.out.println("addTrend: X1 = " + X1 + " X2 = " + X2);
/*  24: 57 */     for (int x = 0; x <= nx; x++) {
/*  25: 58 */       for (int y = 0; y <= ny; y++) {
/*  26: 59 */         for (int z = 0; z <= nz; z++) {
/*  27: 60 */           if (newt[x][y][z] != missingvalue) {
/*  28: 61 */             newt[x][y][z] = (newt[x][y][z] * (X2 * zv[z]) + X1);
/*  29:    */           }
/*  30:    */         }
/*  31:    */       }
/*  32:    */     }
/*  33: 64 */     return newt;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static double[] removeTrendGrid(double[] temp, double[] xx, double[] yy, double[] de, double X1, double X2, String topofile, int ni)
/*  37:    */   {
/*  38: 69 */     System.out.println("removeTrend: X1 = " + X1 + " X2 = " + X2);
/*  39: 70 */     dgm d = new dgm();
/*  40: 71 */     d.readDGM("", topofile);
/*  41:    */     
/*  42: 73 */     topo t = new topo();
/*  43: 74 */     t.cluster2D(d.nr_dgm(), d.dgm_values());
/*  44:    */     
/*  45:    */ 
/*  46: 77 */     double grad = 0.0D;
/*  47: 78 */     int cnt0 = 0;
/*  48: 79 */     for (int i = 0; i < ni; i++) {
/*  49: 80 */       for (int j = 0; j < ni; j++) {
/*  50: 81 */         if ((i != j) && (de[i] != de[j]) && (temp[i] != temp[j]))
/*  51:    */         {
/*  52: 82 */           grad += (temp[i] - temp[j]) / (de[i] - de[j]);
/*  53: 83 */           cnt0++;
/*  54:    */         }
/*  55:    */       }
/*  56:    */     }
/*  57: 87 */     grad /= cnt0;
/*  58: 88 */     System.out.println("average depth trend = " + grad);
/*  59: 91 */     for (int i = 0; i < ni; i++)
/*  60:    */     {
/*  61: 92 */       double teufe = t.getHeight(xx[i], yy[i]);
/*  62: 93 */       if (Math.abs(teufe) > 1.E+032D) {
/*  63: 93 */         System.out.println(i + " Teufe 1: " + teufe + " X = " + xx[i] + " Y = " + yy[i]);
/*  64:    */       }
/*  65: 94 */       teufe -= de[i];
/*  66:    */       
/*  67: 96 */       temp[i] = ((temp[i] - X1) / (X2 * teufe));
/*  68:    */     }
/*  69: 99 */     return temp;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static double[][][] addTrendGrid(double[][][] newt, double[] xx, double[] yy, double[][][] zv, double X1, double X2, String topofile, int nx, int ny, int nz, double missingvalue)
/*  73:    */   {
/*  74:106 */     gridteufe = new double[nx][ny][nz];
/*  75:107 */     dgm d = new dgm();
/*  76:108 */     d.readDGM("", topofile);
/*  77:    */     
/*  78:110 */     topo t = new topo();
/*  79:111 */     t.cluster2D(d.nr_dgm(), d.dgm_values());
/*  80:113 */     for (int x = 0; x < nx; x++) {
/*  81:114 */       for (int y = 0; y < ny; y++) {
/*  82:115 */         for (int z = 0; z < nz; z++)
/*  83:    */         {
/*  84:116 */           gridteufe[x][y][z] = (t.getHeight(xx[x], yy[y]) - zv[x][y][z]);
/*  85:117 */           if (newt[x][y][z] != missingvalue) {
/*  86:118 */             newt[x][y][z] = (newt[x][y][z] * (X2 * gridteufe[x][y][z]) + X1);
/*  87:    */           }
/*  88:    */         }
/*  89:    */       }
/*  90:    */     }
/*  91:121 */     return newt;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public double[][][] gridteufe()
/*  95:    */   {
/*  96:125 */     return gridteufe;
/*  97:    */   }
/*  98:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.trend
 * JD-Core Version:    0.7.0.1
 */