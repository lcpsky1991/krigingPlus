/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.FileInputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStreamReader;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.io.StreamTokenizer;
/*  10:    */ import java.util.StringTokenizer;
/*  11:    */ 
/*  12:    */ public class loadgspar
/*  13:    */ {
/*  14: 75 */   private boolean bErrorVal = false;
/*  15: 76 */   private boolean debug = false;
/*  16:    */   private double xsearchradius;
/*  17:    */   private double ysearchradius;
/*  18:    */   private double zsearchradius;
/*  19:    */   private int nr_of_variogramms;
/*  20:    */   private double nugget;
/*  21:    */   private String[] variogramType;
/*  22:    */   private double[] sill;
/*  23:    */   private double[][] angle;
/*  24:    */   private double[] a_hmax;
/*  25:    */   private double[] a_hmin;
/*  26:    */   private double[] a_vert;
/*  27:    */   private String datafile;
/*  28:    */   private int[] nv;
/*  29:    */   private double[] vmin;
/*  30:    */   private double[] vsize;
/*  31:    */   private int maxoctantdata;
/*  32:    */   private int max_empty_octant;
/*  33:    */   private int kriging_type;
/*  34: 93 */   private double power_par = -9999.8999999999996D;
/*  35: 94 */   private double smoothing_par = -9999.8999999999996D;
/*  36:    */   private int option1;
/*  37:    */   private String jackfile;
/*  38:    */   private String resultfile;
/*  39:    */   private boolean bTrend;
/*  40:    */   private double surftemp;
/*  41:    */   private double gradient;
/*  42:102 */   private int trend_type = 0;
/*  43:    */   private String driftfile;
/*  44:104 */   private int remove_trend = 0;
/*  45:    */   
/*  46:    */   public loadgspar(String parameterfile)
/*  47:    */   {
/*  48:108 */     readpar("", parameterfile);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public loadgspar() {}
/*  52:    */   
/*  53:    */   public static void main(String[] args)
/*  54:    */   {
/*  55:113 */     loadgspar lgsp = new loadgspar();
/*  56:114 */     lgsp.readpar("", "kt3d.par");
/*  57:    */   }
/*  58:    */   
/*  59:    */   private void readpar(String Directory, String Filename)
/*  60:    */   {
/*  61:    */     try
/*  62:    */     {
/*  63:120 */       File f = new File(Directory + Filename);
/*  64:121 */       if (f.length() == 0L) {
/*  65:122 */         System.out.println("Sorry the file you selected has zero length!");
/*  66:    */       }
/*  67:    */     }
/*  68:    */     catch (NullPointerException exc)
/*  69:    */     {
/*  70:124 */       System.out.println(exc);return;
/*  71:    */     }
/*  72:    */     try
/*  73:    */     {
/*  74:126 */       FileInputStream fis = new FileInputStream(Directory + Filename);
/*  75:127 */       BufferedReader r = new BufferedReader(new InputStreamReader(fis));
/*  76:128 */       StreamTokenizer st = new StreamTokenizer(r);
/*  77:    */       
/*  78:    */ 
/*  79:131 */       String[] s2 = new String[3];
/*  80:    */       
/*  81:133 */       st.resetSyntax();
/*  82:134 */       st.whitespaceChars(32, 32);
/*  83:135 */       st.whitespaceChars(10, 10);
/*  84:136 */       st.whitespaceChars(9, 9);
/*  85:137 */       st.whitespaceChars(44, 44);
/*  86:138 */       st.whitespaceChars(59, 59);
/*  87:139 */       st.wordChars(48, 57);
/*  88:140 */       st.wordChars(101, 101);
/*  89:141 */       st.wordChars(69, 69);
/*  90:142 */       st.wordChars(100, 100);
/*  91:143 */       st.wordChars(68, 68);
/*  92:144 */       st.wordChars(46, 46);
/*  93:145 */       st.wordChars(43, 43);
/*  94:146 */       st.wordChars(45, 45);
/*  95:147 */       st.eolIsSignificant(true);
/*  96:    */       
/*  97:149 */       String Scr_1 = null;
/*  98:150 */       for (int i = 0; i < 4; i++) {
/*  99:151 */         Scr_1 = r.readLine();
/* 100:    */       }
/* 101:154 */       int i = 0;
/* 102:155 */       Scr_1 = r.readLine();
/* 103:156 */       StringTokenizer sto = new StringTokenizer(Scr_1);
/* 104:157 */       this.datafile = sto.nextToken();
/* 105:158 */       System.out.println("datafile = " + this.datafile);
/* 106:159 */       i++;
/* 107:160 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 108:161 */       int cx = Integer.valueOf(sto.nextToken()).intValue();
/* 109:162 */       i++;
/* 110:163 */       int cy = Integer.valueOf(sto.nextToken()).intValue();
/* 111:164 */       i++;
/* 112:165 */       int cz = Integer.valueOf(sto.nextToken()).intValue();
/* 113:166 */       i++;
/* 114:167 */       int cv1 = Integer.valueOf(sto.nextToken()).intValue();
/* 115:168 */       i++;
/* 116:169 */       int cv2 = Integer.valueOf(sto.nextToken()).intValue();
/* 117:170 */       i++;
/* 118:171 */       if (cv2 == 5) {
/* 119:171 */         this.bErrorVal = true;
/* 120:    */       }
/* 121:172 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 122:173 */       double lowtrim = Double.valueOf(sto.nextToken()).doubleValue();
/* 123:174 */       i++;
/* 124:175 */       double hightrim = Double.valueOf(sto.nextToken()).doubleValue();
/* 125:176 */       i++;
/* 126:177 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 127:178 */       this.option1 = Integer.valueOf(sto.nextToken()).intValue();
/* 128:179 */       System.out.println("option1 : " + this.option1);
/* 129:180 */       i++;
/* 130:181 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 131:182 */       this.jackfile = sto.nextToken();
/* 132:183 */       System.out.println("jackfile = " + this.jackfile);
/* 133:184 */       i++;
/* 134:185 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 135:186 */       int jcx = Integer.valueOf(sto.nextToken()).intValue();
/* 136:187 */       i++;
/* 137:188 */       int jcy = Integer.valueOf(sto.nextToken()).intValue();
/* 138:189 */       i++;
/* 139:190 */       int jcz = Integer.valueOf(sto.nextToken()).intValue();
/* 140:191 */       i++;
/* 141:192 */       int jcv1 = Integer.valueOf(sto.nextToken()).intValue();
/* 142:193 */       i++;
/* 143:194 */       int jcv2 = Integer.valueOf(sto.nextToken()).intValue();
/* 144:195 */       i++;
/* 145:196 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 146:197 */       int debuglevel = Integer.valueOf(sto.nextToken()).intValue();
/* 147:198 */       if (debuglevel > 0) {
/* 148:198 */         this.debug = true;
/* 149:    */       }
/* 150:199 */       i++;
/* 151:200 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 152:201 */       String debugfile = sto.nextToken();
/* 153:202 */       System.out.println("debugfile = " + debugfile);
/* 154:203 */       i++;
/* 155:204 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 156:205 */       this.resultfile = sto.nextToken();
/* 157:206 */       System.out.println("resultfile = " + this.resultfile);
/* 158:207 */       i++;
/* 159:    */       
/* 160:209 */       this.nv = new int[3];
/* 161:210 */       this.vmin = new double[3];
/* 162:211 */       this.vsize = new double[3];
/* 163:212 */       for (int j = 0; j < 3; j++)
/* 164:    */       {
/* 165:213 */         Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 166:214 */         this.nv[j] = Integer.valueOf(sto.nextToken()).intValue();
/* 167:215 */         i++;
/* 168:216 */         this.vmin[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 169:217 */         i++;
/* 170:218 */         this.vsize[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 171:219 */         i++;
/* 172:    */       }
/* 173:221 */       int[] blocksize = new int[3];
/* 174:222 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 175:223 */       for (int j = 0; j < 3; j++)
/* 176:    */       {
/* 177:224 */         blocksize[j] = Integer.valueOf(sto.nextToken()).intValue();
/* 178:225 */         i++;
/* 179:    */       }
/* 180:227 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 181:228 */       int minkdata = Integer.valueOf(sto.nextToken()).intValue();
/* 182:229 */       i++;
/* 183:230 */       int maxkdata = Integer.valueOf(sto.nextToken()).intValue();
/* 184:231 */       i++;
/* 185:232 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 186:233 */       this.maxoctantdata = Integer.valueOf(sto.nextToken()).intValue();
/* 187:234 */       i++;
/* 188:235 */       this.max_empty_octant = Integer.valueOf(sto.nextToken()).intValue();
/* 189:236 */       i++;
/* 190:237 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 191:238 */       this.xsearchradius = Double.valueOf(sto.nextToken()).doubleValue();
/* 192:239 */       i++;
/* 193:240 */       this.ysearchradius = Double.valueOf(sto.nextToken()).doubleValue();
/* 194:241 */       i++;
/* 195:242 */       this.zsearchradius = Double.valueOf(sto.nextToken()).doubleValue();
/* 196:243 */       i++;
/* 197:244 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 198:245 */       double x_angle_search_ellipsoid = Double.valueOf(sto.nextToken()).doubleValue();
/* 199:246 */       i++;
/* 200:247 */       double y_angle_search_ellipsoid = Double.valueOf(sto.nextToken()).doubleValue();
/* 201:248 */       i++;
/* 202:249 */       double z_angle_search_ellipsoid = Double.valueOf(sto.nextToken()).doubleValue();
/* 203:250 */       i++;
/* 204:251 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 205:252 */       this.kriging_type = Integer.valueOf(sto.nextToken()).intValue();
/* 206:253 */       i++;
/* 207:254 */       if (this.kriging_type == 0)
/* 208:    */       {
/* 209:255 */         this.power_par = Double.valueOf(sto.nextToken()).doubleValue();
/* 210:256 */         i++;
/* 211:257 */         this.smoothing_par = Double.valueOf(sto.nextToken()).doubleValue();
/* 212:258 */         i++;
/* 213:    */       }
/* 214:260 */       double[] drift = new double[9];
/* 215:261 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 216:262 */       for (int j = 0; j < 9; j++)
/* 217:    */       {
/* 218:263 */         drift[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 219:264 */         i++;
/* 220:    */       }
/* 221:266 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 222:267 */       this.trend_type = Integer.valueOf(sto.nextToken()).intValue();
/* 223:268 */       System.out.println("trend file is used (0=n/1=y): " + this.trend_type);
/* 224:269 */       i++;
/* 225:270 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 226:271 */       this.driftfile = sto.nextToken();
/* 227:272 */       System.out.println("driftfile = " + this.driftfile);
/* 228:273 */       i++;
/* 229:274 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 230:275 */       int drift_column_number = Integer.valueOf(sto.nextToken()).intValue();
/* 231:276 */       i++;
/* 232:277 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 233:278 */       this.nr_of_variogramms = Integer.valueOf(sto.nextToken()).intValue();
/* 234:279 */       i++;
/* 235:280 */       this.nugget = Double.valueOf(sto.nextToken()).doubleValue();
/* 236:281 */       i++;
/* 237:    */       
/* 238:283 */       int[] variogram_type = new int[this.nr_of_variogramms];
/* 239:284 */       this.sill = new double[this.nr_of_variogramms];
/* 240:285 */       this.angle = new double[this.nr_of_variogramms][3];
/* 241:286 */       this.a_hmax = new double[this.nr_of_variogramms];
/* 242:287 */       this.a_hmin = new double[this.nr_of_variogramms];
/* 243:288 */       this.a_vert = new double[this.nr_of_variogramms];
/* 244:289 */       this.variogramType = new String[this.nr_of_variogramms];
/* 245:290 */       for (int j = 0; j < this.nr_of_variogramms; j++)
/* 246:    */       {
/* 247:291 */         Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 248:292 */         variogram_type[j] = Integer.valueOf(sto.nextToken()).intValue();
/* 249:293 */         if (variogram_type[j] == 1) {
/* 250:293 */           this.variogramType[j] = "spherical";
/* 251:294 */         } else if (variogram_type[j] == 2) {
/* 252:294 */           this.variogramType[j] = "exponentiell";
/* 253:295 */         } else if (variogram_type[j] == 3) {
/* 254:295 */           this.variogramType[j] = "gaussian";
/* 255:296 */         } else if (variogram_type[j] == 4) {
/* 256:296 */           this.variogramType[j] = "power";
/* 257:297 */         } else if (variogram_type[j] == 5) {
/* 258:297 */           this.variogramType[j] = "hole_effect";
/* 259:298 */         } else if (variogram_type[j] == 6) {
/* 260:298 */           this.variogramType[j] = "linear";
/* 261:299 */         } else if (variogram_type[j] == 7) {
/* 262:299 */           this.variogramType[j] = "matern";
/* 263:    */         }
/* 264:300 */         i++;
/* 265:301 */         this.sill[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 266:302 */         i++;
/* 267:303 */         this.angle[j][0] = Double.valueOf(sto.nextToken()).doubleValue();
/* 268:304 */         i++;
/* 269:305 */         this.angle[j][1] = Double.valueOf(sto.nextToken()).doubleValue();
/* 270:306 */         i++;
/* 271:307 */         this.angle[j][2] = Double.valueOf(sto.nextToken()).doubleValue();
/* 272:308 */         i++;
/* 273:309 */         Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 274:310 */         this.a_hmax[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 275:311 */         i++;
/* 276:312 */         this.a_hmin[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 277:313 */         i++;
/* 278:314 */         this.a_vert[j] = Double.valueOf(sto.nextToken()).doubleValue();
/* 279:315 */         i++;
/* 280:    */       }
/* 281:317 */       Scr_1 = r.readLine();sto = new StringTokenizer(Scr_1);
/* 282:318 */       this.remove_trend = Integer.valueOf(sto.nextToken()).intValue();
/* 283:319 */       if (this.remove_trend == 1)
/* 284:    */       {
/* 285:320 */         this.bTrend = true;
/* 286:321 */         this.surftemp = Double.valueOf(sto.nextToken()).doubleValue();
/* 287:322 */         this.gradient = Double.valueOf(sto.nextToken()).doubleValue();
/* 288:    */       }
/* 289:    */     }
/* 290:    */     catch (IOException ioe) {}
/* 291:    */   }
/* 292:    */   
/* 293:    */   public String[] variogramType()
/* 294:    */   {
/* 295:328 */     return this.variogramType;
/* 296:    */   }
/* 297:    */   
/* 298:    */   public double[] searchradius()
/* 299:    */   {
/* 300:331 */     double[] sr = new double[3];
/* 301:332 */     sr[0] = this.xsearchradius;
/* 302:333 */     sr[1] = this.ysearchradius;
/* 303:334 */     sr[2] = this.zsearchradius;
/* 304:335 */     return sr;
/* 305:    */   }
/* 306:    */   
/* 307:    */   public double nugget()
/* 308:    */   {
/* 309:338 */     return this.nugget;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public double[] sill()
/* 313:    */   {
/* 314:341 */     return this.sill;
/* 315:    */   }
/* 316:    */   
/* 317:    */   public double[][] variogram_angle()
/* 318:    */   {
/* 319:344 */     return this.angle;
/* 320:    */   }
/* 321:    */   
/* 322:    */   public double[] maxRange()
/* 323:    */   {
/* 324:347 */     return this.a_hmax;
/* 325:    */   }
/* 326:    */   
/* 327:    */   public double[] minRange()
/* 328:    */   {
/* 329:350 */     return this.a_hmin;
/* 330:    */   }
/* 331:    */   
/* 332:    */   public double[] zRange()
/* 333:    */   {
/* 334:353 */     return this.a_vert;
/* 335:    */   }
/* 336:    */   
/* 337:    */   public String inputdatafile()
/* 338:    */   {
/* 339:356 */     return this.datafile;
/* 340:    */   }
/* 341:    */   
/* 342:    */   public boolean bErrorVal()
/* 343:    */   {
/* 344:359 */     return this.bErrorVal;
/* 345:    */   }
/* 346:    */   
/* 347:    */   public boolean debug()
/* 348:    */   {
/* 349:362 */     return this.debug;
/* 350:    */   }
/* 351:    */   
/* 352:    */   public double xsearchradius()
/* 353:    */   {
/* 354:365 */     return this.xsearchradius;
/* 355:    */   }
/* 356:    */   
/* 357:    */   public double ysearchradius()
/* 358:    */   {
/* 359:368 */     return this.ysearchradius;
/* 360:    */   }
/* 361:    */   
/* 362:    */   public double zsearchradius()
/* 363:    */   {
/* 364:371 */     return this.zsearchradius;
/* 365:    */   }
/* 366:    */   
/* 367:    */   public int[] nv()
/* 368:    */   {
/* 369:374 */     return this.nv;
/* 370:    */   }
/* 371:    */   
/* 372:    */   public double[] vmin()
/* 373:    */   {
/* 374:377 */     return this.vmin;
/* 375:    */   }
/* 376:    */   
/* 377:    */   public double[] vsize()
/* 378:    */   {
/* 379:380 */     return this.vsize;
/* 380:    */   }
/* 381:    */   
/* 382:    */   public int nr_of_variogramms()
/* 383:    */   {
/* 384:383 */     return this.nr_of_variogramms;
/* 385:    */   }
/* 386:    */   
/* 387:    */   public int maxoctantdata()
/* 388:    */   {
/* 389:386 */     return this.maxoctantdata;
/* 390:    */   }
/* 391:    */   
/* 392:    */   public int max_empty_octant()
/* 393:    */   {
/* 394:389 */     return this.max_empty_octant;
/* 395:    */   }
/* 396:    */   
/* 397:    */   public int kriging_type()
/* 398:    */   {
/* 399:392 */     return this.kriging_type;
/* 400:    */   }
/* 401:    */   
/* 402:    */   public double power_par()
/* 403:    */   {
/* 404:395 */     return this.power_par;
/* 405:    */   }
/* 406:    */   
/* 407:    */   public double smoothing_par()
/* 408:    */   {
/* 409:398 */     return this.smoothing_par;
/* 410:    */   }
/* 411:    */   
/* 412:    */   public int jacknife()
/* 413:    */   {
/* 414:401 */     return this.option1;
/* 415:    */   }
/* 416:    */   
/* 417:    */   public String jackfile()
/* 418:    */   {
/* 419:404 */     return this.jackfile;
/* 420:    */   }
/* 421:    */   
/* 422:    */   public String resultfile()
/* 423:    */   {
/* 424:407 */     return this.resultfile;
/* 425:    */   }
/* 426:    */   
/* 427:    */   public boolean bTrend()
/* 428:    */   {
/* 429:410 */     return this.bTrend;
/* 430:    */   }
/* 431:    */   
/* 432:    */   public double gradient()
/* 433:    */   {
/* 434:413 */     return this.gradient;
/* 435:    */   }
/* 436:    */   
/* 437:    */   public double surftemp()
/* 438:    */   {
/* 439:416 */     return this.surftemp;
/* 440:    */   }
/* 441:    */   
/* 442:    */   public String driftfile()
/* 443:    */   {
/* 444:419 */     return this.driftfile;
/* 445:    */   }
/* 446:    */   
/* 447:    */   public int trend_type()
/* 448:    */   {
/* 449:422 */     return this.trend_type;
/* 450:    */   }
/* 451:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.loadgspar
 * JD-Core Version:    0.7.0.1
 */