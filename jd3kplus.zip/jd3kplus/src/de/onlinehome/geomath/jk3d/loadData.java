/*   1:    */ package de.onlinehome.geomath.jk3d;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.FileInputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStreamReader;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.io.StreamTokenizer;
/*  10:    */ import java.util.StringTokenizer;
/*  11:    */ import java.util.Vector;
/*  12:    */ 
/*  13:    */ public class loadData
/*  14:    */ {
/*  15:    */   private double[][] dAllValues;
/*  16:    */   
/*  17:    */   public loadData(boolean gslib, boolean debug, String filename)
/*  18:    */   {
/*  19: 42 */     boolean skip_first_line = false;
/*  20: 43 */     int i = 0;int j = 0;
/*  21: 45 */     if (debug) {
/*  22: 45 */       System.out.println("loading " + filename + " " + gslib + " " + debug);
/*  23:    */     }
/*  24: 47 */     Vector<String> v2 = new Vector();
/*  25:    */     try
/*  26:    */     {
/*  27: 49 */       File f = new File(filename);
/*  28: 50 */       if (f.length() == 0L) {
/*  29: 51 */         System.out.println("Sorry the file you selected has zero length!");
/*  30:    */       }
/*  31:    */     }
/*  32:    */     catch (NullPointerException exc)
/*  33:    */     {
/*  34: 53 */       System.out.println(exc);return;
/*  35:    */     }
/*  36:    */     try
/*  37:    */     {
/*  38: 56 */       FileInputStream fis = new FileInputStream(filename);
/*  39: 57 */       BufferedReader r = new BufferedReader(new InputStreamReader(fis));
/*  40: 58 */       StreamTokenizer st = new StreamTokenizer(r);
/*  41:    */       
/*  42:    */ 
/*  43: 61 */       st.resetSyntax();
/*  44: 62 */       st.whitespaceChars(32, 32);
/*  45: 63 */       st.whitespaceChars(10, 10);
/*  46: 64 */       st.whitespaceChars(9, 9);
/*  47: 65 */       st.whitespaceChars(44, 44);
/*  48: 66 */       st.whitespaceChars(59, 59);
/*  49: 67 */       st.wordChars(48, 57);
/*  50: 68 */       st.wordChars(101, 101);
/*  51: 69 */       st.wordChars(69, 69);
/*  52: 70 */       st.wordChars(46, 46);
/*  53: 71 */       st.wordChars(43, 43);
/*  54: 72 */       st.wordChars(45, 45);
/*  55: 73 */       st.eolIsSignificant(true);
/*  56: 75 */       if (gslib)
/*  57:    */       {
/*  58: 77 */         String scr = null;
/*  59: 78 */         r.readLine();
/*  60: 79 */         scr = r.readLine();
/*  61: 80 */         StringTokenizer strt = new StringTokenizer(scr);
/*  62: 81 */         int nr_val = Integer.valueOf(strt.nextToken()).intValue();
/*  63: 82 */         for (int q = 0; i < nr_val; i++) {
/*  64: 83 */           r.readLine();
/*  65:    */         }
/*  66:    */       }
/*  67: 86 */       else if (skip_first_line)
/*  68:    */       {
/*  69: 86 */         r.readLine();
/*  70:    */       }
/*  71: 89 */       j = 0;
/*  72: 90 */       i = 0;
/*  73: 91 */       while (st.nextToken() != -1)
/*  74:    */       {
/*  75: 92 */         String s1 = st.sval;
/*  76: 93 */         if (s1 != null)
/*  77:    */         {
/*  78: 94 */           v2.addElement(s1);
/*  79: 95 */           i = st.lineno();
/*  80:    */         }
/*  81:    */       }
/*  82:    */     }
/*  83:    */     catch (IOException ioe) {}
/*  84: 99 */     int ni = i;
/*  85:100 */     int nj = v2.size() / ni;
/*  86:102 */     if (debug) {
/*  87:102 */       System.out.println("v2.size() = " + v2.size() + " number_of_rows = " + ni + " number_of_columns = " + nj);
/*  88:    */     }
/*  89:104 */     this.dAllValues = new double[ni][nj];
/*  90:105 */     int k = 0;
/*  91:106 */     for (i = 0; i < ni; i++) {
/*  92:107 */       for (j = 0; j < nj; j++)
/*  93:    */       {
/*  94:108 */         Object f = v2.elementAt(k);
/*  95:109 */         String s = f.toString();
/*  96:110 */         this.dAllValues[i][j] = Double.valueOf(s).doubleValue();
/*  97:111 */         k++;
/*  98:    */       }
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public double[][] val()
/* 103:    */   {
/* 104:117 */     return this.dAllValues;
/* 105:    */   }
/* 106:    */ }


/* Location:           F:\jk3dstudy\lib\jk3d.jar
 * Qualified Name:     de.onlinehome.geomath.jk3d.loadData
 * JD-Core Version:    0.7.0.1
 */