package de.onlinehome.geomath.jk3d;

import Jama.Matrix;
import java.io.PrintStream;

public class jk3d
{
  protected double[][] data;
  protected double[][][] newt;
  protected Matrix A;
  protected Matrix b;
  protected Matrix x;
  protected Matrix zdata;
  static final double MISSING_VALUE = 1.70141E+038D;
  
  public jk3d(String parameterfile)
  {
    loadgspar lgspar = new loadgspar(parameterfile);
    loadData ld = new loadData(true, lgspar.debug(), lgspar.inputdatafile());
    this.data = ld.val();
    int ni = this.data.length;
    int nj = this.data[1].length;
    System.out.println("ni,nj: " + ni + " " + nj + " - lgspar.kriging_type(): " + lgspar.kriging_type());
    






    double x0 = lgspar.vmin()[0];
    double y0 = lgspar.vmin()[1];
    double z0 = lgspar.vmin()[2];
    double x1 = lgspar.vmin()[0] + lgspar.nv()[0] * lgspar.vsize()[0];
    double y1 = lgspar.vmin()[1] + lgspar.nv()[1] * lgspar.vsize()[1];
    double z1 = lgspar.vmin()[2] + lgspar.nv()[2] * lgspar.vsize()[2];
    




    rmDoubles rmd = new rmDoubles(ni, this.data);
    
    String savefilename = lgspar.resultfile();
    String savedirectory = "";
    krige3d k3d;
    boolean normalize_only_z;
    if (lgspar.kriging_type() == 1)
    {
      System.out.println("applying kriging");
      boolean b_trend = lgspar.bTrend();
      double X1 = lgspar.surftemp();
      double X2 = lgspar.gradient();
      k3d = new krige3d(rmd.ni(), rmd.data(), lgspar.nv()[0], lgspar.nv()[1], lgspar.nv()[2], lgspar.vmin()[0], lgspar.vmin()[1], lgspar.vmin()[2], lgspar.vsize()[0], lgspar.vsize()[1], lgspar.vsize()[2], lgspar.bErrorVal(), lgspar.debug(), lgspar.nr_of_variogramms(), lgspar.maxRange(), lgspar.minRange(), lgspar.zRange(), lgspar.variogram_angle(), lgspar.sill(), lgspar.nugget(), lgspar.variogramType(), lgspar.searchradius()[0], lgspar.searchradius()[1], lgspar.searchradius()[2], lgspar.maxoctantdata(), lgspar.max_empty_octant(), savedirectory, savefilename, b_trend, X1, X2, lgspar.trend_type(), lgspar.driftfile(), 1.70141E+038D);
    }
    else
    {
      calciw3d ciw3d;
      if (lgspar.kriging_type() == 0)
      {
        System.out.println("applying inverse distance weighting");
        boolean b_trend = lgspar.bTrend();
        double X1 = lgspar.surftemp();
        double X2 = lgspar.gradient();
        String topofile = lgspar.driftfile();
        int assign_missing_value_when_lessdata_than = 1;
        boolean bErrorVal = true;
        int i_normalize = 0;
        normalize_only_z = false;
        System.out.println("lgspar.jackfile() : " + lgspar.jackfile());
        ciw3d = new calciw3d(rmd.ni(), rmd.data(), lgspar.nv()[0], lgspar.nv()[1], lgspar.nv()[2], lgspar.vmin()[0], lgspar.vmin()[1], lgspar.vmin()[2], lgspar.vsize()[0], lgspar.vsize()[1], lgspar.vsize()[2], lgspar.power_par(), lgspar.smoothing_par(), b_trend, X1, X2, topofile, assign_missing_value_when_lessdata_than, 1.70141E+038D, bErrorVal, lgspar.debug(), lgspar.searchradius()[0], lgspar.searchradius()[1], lgspar.searchradius()[2], lgspar.maxoctantdata(), lgspar.max_empty_octant(), i_normalize, normalize_only_z, savedirectory + savefilename, lgspar.jacknife(), lgspar.jackfile());
      }
      else if ((lgspar.kriging_type() == 0) && (lgspar.jacknife() == 3))
      {
        boolean b_trend = false;
        double X1 = 1.0D;
        double X2 = 1.0D;
        int assign_missing_value_when_lessdata_than = 1;
        boolean bErrorVal = true;
        int i_normalize = 0;
        normalize_only_z = false;
      }
    }
  }
  
  public static void main(String[] args)
  {
    String inputfile = null;
    double begin = System.currentTimeMillis();
    
    System.out.println("jk3d version 1.1");
    if (args.length == 1)
    {
      inputfile = args[0];
    }
    else
    {
      System.out.println("Please use a syntax like: \n$java -Xmx256m -jar jk3d.jar parameter-filename");
      

      System.exit(10);
    }
    new jk3d(inputfile);
    double end = System.currentTimeMillis();
    System.out.println("Time = " + (end - begin) / 1000.0D + " sec");
    System.exit(0);
  }
}
